/*
    \file   main.c

    \brief  Main source file.

    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <interrupt_avr8.h>
#include <string.h>
#include "atmel_start.h"
#include "kit_process.h"

static enum kit_protocol_status kitBoardApplication(uint32_t device_handle, uint8_t *message, uint16_t *message_length)
{
    JSON_Value *command_value = NULL;
    JSON_Object *command_object = NULL;
    JSON_Object *params_object = NULL;
    
    JSON_Value *response_value = NULL;
    JSON_Object *response_object = NULL;
    JSON_Value *result_value = NULL;
    JSON_Object *result_object = NULL;

    uint16_t max_message_length = kit_interpreter_get_max_message_length();
    char *message_method = NULL;
    int message_id = 0;
    
    command_value   = json_parse_string((char*)message);
    command_object  = json_value_get_object(command_value);
    params_object   = json_object_get_object(command_object, "params");

    response_value  = json_value_init_object();
    response_object = json_value_get_object(response_value);

    result_value    = json_value_init_object();
    result_object   = json_value_get_object(result_value);
    
    // Get the incoming Board Application command message method
    message_method = (char*)json_object_get_string(command_object, "method");
    // Get the incoming Board Application command message id
    message_id = json_object_get_number(command_object, "id");
    
    if (strcmp(message_method, "init") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch Init command message
        process_board_application_init(params_object, result_object);
    }

    if (strcmp(message_method, "genCsr") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch genCsr command message
        process_board_application_gen_csr(params_object, result_object);
    }

    if (strcmp(message_method, "saveCredentials") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch saveCredentials command message
        process_board_application_save_credentials(params_object, result_object);
    }
    
 
    json_object_set_value(response_object, "result", result_value);
    result_value = NULL;
         
    // No error occurred during processing of the AWS IoT Zero Touch  Demo command message
    json_object_set_null(response_object, "error");

    // Set the outgoing AWS IoT Zero Touch response message id
    json_object_set_number(response_object, "id", message_id);
     
    // Save the Set the outgoing AWS IoT Zero Touch response message
    memset(&message[0], 0, max_message_length);
    *message_length = (json_serialization_size(response_value) - 1);
    json_serialize_to_buffer(response_value, (char*)message, max_message_length);

    // Free allocated memory
    json_value_free(command_value);
    json_value_free(result_value);
    json_value_free(response_value);

    return KIT_STATUS_SUCCESS;
}

static void kitComWriteString(char * str)
{
    for(size_t i = 0; i <= strlen(str); i++)
    {
        USART_0_write(str[i]);
    }
}

static char kitComReadChar()
{
    return (char)USART_0_read();
}

int main(void)
{	
    char c;     
	char kitMessage[KIT_MESSAGE_SIZE_MAX];
    uint16_t idx = 0;
    
    atmel_start_init();
    Enable_global_interrupt();
    cryptoauthlib_init();
    
	while (1) 
	{
        c = kitComReadChar();	
        if(c != '\n')
        {
            kitMessage[idx++] = c;
        }
        else
        {
            kitMessage[idx++] = '\0';
            
            kitBoardApplication(0, (uint8_t*)kitMessage, &idx);
            kitComWriteString(kitMessage);

            idx = 0;    
        }
	}
	
	return 0;
}
