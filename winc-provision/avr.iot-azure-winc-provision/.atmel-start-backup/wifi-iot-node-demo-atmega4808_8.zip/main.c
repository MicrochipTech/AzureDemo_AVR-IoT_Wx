/*
    \file   main.c

    \brief  Main source file.

    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <interrupt_avr8.h>
#include <string.h>
#include "atmel_start.h"
#include "kit_process.h"
#include "ecc_functions_tls.h"
#include <stdlib.h>
#define KEY_ID_SIZE     (20)
char mqtt_client_id[2*KEY_ID_SIZE + 1];
#include "cert_def_3_device_csr.h"
void intToHex(char *destination, uint8_t source)
{
    destination[0] = "0123456789abcdef"[source >> 4];
    destination[1] = "0123456789abcdef"[source & 0x0F];
}
char *message_method;
char *argument;
static enum kit_protocol_status kitBoardApplication(uint32_t device_handle, uint8_t *message, uint16_t *message_length)
{
    message_method = message;
    argument = strchr(message, ':');
    *argument = '\0';
    argument++;
    
     //process_board_application_save_credentials(params_object, result_object);

    if (strcmp(message_method, "caPubKey") == 0)
    {
         kit_protocol_convert_hex_to_binary(strlen(argument), argument);
// 
        signer_ca_public_key_size = 64;
        memcpy(g_signer_1_ca_public_key, &argument[0], 64);
//         
         memcpy(message, "Done.\0", 6);
    }
    
    if (strcmp(message_method, "caCert") == 0)
    {
        uint16_t cert_size;
//         uint8_t credentials_buffer[10];
//         uint16_t credentials_buffer_length = 0;
//         credentials_buffer_length = strlen(argument);
//         memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
//         memcpy(&credentials_buffer[0], &argument[0], credentials_buffer_length);
//         
        cert_size = kit_protocol_convert_hex_to_binary(strlen(argument), argument);
        
        memcpy(signer_cert, argument, cert_size);
        signer_cert_size = cert_size;
        
        memcpy(message, "Done.\0", 6);
    }
    
    if (strcmp(message_method, "deviceCert") == 0)
    {
        uint16_t cert_size;
//         uint8_t credentials_buffer[10];
//         uint16_t credentials_buffer_length = 0;
//         credentials_buffer_length = ;
//         memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
//         memcpy(&credentials_buffer[0], &argument[0], credentials_buffer_length);
//         
        cert_size = kit_protocol_convert_hex_to_binary(strlen(argument), argument);
        
        memcpy(device_cert, argument, cert_size);
        device_cert_size = cert_size;
        
        memcpy(message, "Done.\0", 6);
    }
    
    if (strcmp(message_method, "transferCertificates") == 0)
    {
        uint8_t subject_key_id[KEY_ID_SIZE];
        cryptoauthlib_init();
        ecc_transfer_certificates(subject_key_id);
        
        for (uint8_t i = 0; i < KEY_ID_SIZE; i++)
        {
            intToHex(mqtt_client_id + 2 * i, subject_key_id[i]);
        }
        mqtt_client_id[KEY_ID_SIZE * 2] = 0;
        
        memcpy(message, "Done.\0", 6);
    }
    
    if (strcmp(message_method, "genCsr") == 0)
    {
        ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
        uint8_t *csr_buffer = (uint8_t*) sector_buffer;
        size_t csr_buffer_length = 1500;
        
       
        // Generate the AWS IoT device CSR
        atca_status = atcacert_create_csr(&g_csr_def_3_device, csr_buffer, &csr_buffer_length);
            
        if (atca_status == ATCA_SUCCESS)
        {
            kit_protocol_convert_binary_to_hex((uint16_t)csr_buffer_length, csr_buffer);
            csr_buffer[2 * csr_buffer_length] = '\0';
        }
        
        memcpy(message, csr_buffer, 2 * csr_buffer_length + 1);
        
        init_sector_buffer();
    }
    
    return KIT_STATUS_SUCCESS;
}

static void kitComWriteString(char * str)
{
    for(size_t i = 0; i <= strlen(str); i++)
    {
        USART_0_write(str[i]);
    }
}

static char kitComReadChar()
{
    return (char)USART_0_read();
}

#include "winc/driver/include/m2m_wifi.h"
#include "winc/socket/include/socket.h"

static void aws_wifi_ssl_callback(uint8 u8MsgType, void *pvMsg)
{
    switch (u8MsgType)
    {
        case M2M_SSL_REQ_ECC:
        {
            break;
        }
        
        case M2M_SSL_RESP_SET_CS_LIST:
        {
            tstrSslSetActiveCsList *pstrCsList = (tstrSslSetActiveCsList *)pvMsg;
            M2M_INFO("ActiveCS bitmap:%04x\n", pstrCsList->u32CsBMP);
            break;
        }
        
        default:
        // Do nothing
        break;
    }
}

static void aws_wifi_callback(uint8 u8MsgType, void *pvMsg)
{
    switch (u8MsgType)
    {
        case M2M_WIFI_REQ_DHCP_CONF:
        break;
    }
}

int main(void)
{	
    char c;     
	char kitMessage[KIT_MESSAGE_SIZE_MAX];
    uint16_t idx = 0;
    
    atmel_start_init();
    Enable_global_interrupt();
    cryptoauthlib_init();
    
    tstrWifiInitParam wifi_paramaters;
    m2m_memset((uint8*)&wifi_paramaters, 0, sizeof(wifi_paramaters));
    wifi_paramaters.pfAppWifiCb = aws_wifi_callback;

    
    nm_bsp_init();
    m2m_wifi_init(&wifi_paramaters);
    m2m_ssl_init(aws_wifi_ssl_callback);
    
    m2m_ssl_set_active_ciphersuites((uint32)SSL_ECC_ONLY_CIPHERS);
    
    
    
    
    
	while (1) 
	{
        c = kitComReadChar();	
        if(c != '\0')
        {
            kitMessage[idx++] = c;
        }
        else
        {
            kitMessage[idx++] = '\0';
            
            kitBoardApplication(0, (uint8_t*)kitMessage, &idx);
            kitComWriteString(kitMessage);

            idx = 0;    
        }
	}
	
	return 0;
}
