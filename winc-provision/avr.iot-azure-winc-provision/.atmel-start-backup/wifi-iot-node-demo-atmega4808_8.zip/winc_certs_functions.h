/* 
    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#ifndef WINC_CERTS_FUNCTIONS_H_
#define WINC_CERTS_FUNCTIONS_H_

#include <stdint.h>
#include <stddef.h>
#include "winc/bsp/include/nm_bsp.h"
#include "winc/driver/include/m2m_types.h"
#include "cert_def_1_signer.h"
#include "cert_def_2_device.h"
#include "cryptoauthlib/lib/cryptoauthlib.h"

#define SIGNER_PUBLIC_KEY_MAX_LEN     64
#define SIGNER_CA_PUBLIC_KEY_SLOT  (15)
#define MAX_TLS_CERT_LENGTH            900
#define CERT_SN_MAX_LEN                32

#define SIGNER_CERT_MAX_LEN         (g_cert_def_1_signer.cert_template_size + 8) // Need some space in case the cert changes size by a few bytes
#define DEVICE_CERT_MAX_LEN            (g_cert_def_2_device.cert_template_size + 8) // Need some space in case the cert changes size by a few bytes
#define INIT_CERT_BUFFER_LEN        (MAX_TLS_CERT_LENGTH*sizeof(uint32) - TLS_FILE_NAME_MAX*2 - SIGNER_CERT_MAX_LEN - DEVICE_CERT_MAX_LEN)
#define TLS_SRV_ECDSA_CHAIN_FILE    "ECDSA.lst"

// TODO: follow module public functions naming convention
ATCA_STATUS provisioning_get_signer_ca_public_key(uint32_t *public_key_length, uint8_t *public_key);
sint8 winc_certs_append_file_buf(uint32* buffer32, uint32 buffer_size, const char* file_name, uint32 file_size, const uint8* file_data);
size_t winc_certs_get_total_files_size(const tstrTlsSrvSecHdr* header);



#endif /* WINC_CERTS_FUNCTIONS_H_ */