/*
    \file   main.c

    \brief  Main source file.

    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
#define DEVICE_KEY_SLOT            (0)
#define SIGNER_CA_PUBLIC_KEY_SLOT  (15)

#include <stdint.h>
#include "parson_json/parson.h"
#include "kit_protocol/kit_protocol_interpreter.h"
#include "cryptoauthlib/lib/cryptoauthlib.h"
#include "ecc_functions_tls.h"
#include "cert_def_1_signer.h"
#include "cert_def_2_device.h"
#include "cert_def_3_device_csr.h"

enum kit_protocol_status process_board_application_init(JSON_Object *params_object,
                                                               JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t serial_number[ATCA_SERIAL_NUM_SIZE];
    uint8_t public_key[ATCA_PUB_KEY_SIZE];
    char ascii_buffer[150];
    
    do 
    {
        // Get the ATECCx08A device serial number
        memset(&serial_number[0], 0, sizeof(serial_number));
        atca_status = atcab_read_serial_number(serial_number);
        if (atca_status == ATCA_SUCCESS)
        {
            // Save the ATECCx08A device serial number
            memset(&ascii_buffer[0], 0, sizeof(ascii_buffer));
            memcpy(&ascii_buffer[0], &serial_number[0], sizeof(serial_number));
        
            kit_protocol_convert_binary_to_hex(sizeof(serial_number), 
                                               (uint8_t*)ascii_buffer);
            json_object_set_string(result_object, "deviceSn", ascii_buffer);
        }

        // Get the ATECCx08A device public key
        memset(&public_key[0], 0, sizeof(public_key));
        atca_status = atcab_genkey_base(GENKEY_MODE_PUBLIC, DEVICE_KEY_SLOT, 
                                        NULL, public_key);
        if (atca_status == ATCA_SUCCESS)
        {
            // Save the ATECCx08A device public key
            memset(&ascii_buffer[0], 0, sizeof(ascii_buffer));
            memcpy(&ascii_buffer[0], &public_key[0], sizeof(public_key));
            
            kit_protocol_convert_binary_to_hex(sizeof(public_key), 
                                               (uint8_t*)ascii_buffer);
            json_object_set_string(result_object, "devicePublicKey", ascii_buffer);
        }
    } while (false);
    
    // The AWS IoT Zero Touch Demo init message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
};


enum kit_protocol_status process_board_application_gen_csr(JSON_Object *params_object,
                                                                  JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    //uint8_t csr_buffer[1500];
    uint8_t *csr_buffer = (uint8_t*) sector_buffer;
    size_t csr_buffer_length= 0;
    
    do
    {
        // Generate the AWS IoT device CSR
        csr_buffer_length = 1500;
        atca_status = atcacert_create_csr(&g_csr_def_3_device, csr_buffer, 
                                          &csr_buffer_length);
        
        if (atca_status == ATCA_SUCCESS)
        {
            kit_protocol_convert_binary_to_hex((uint16_t)csr_buffer_length, 
                                               csr_buffer);
            csr_buffer[2 * csr_buffer_length] = '\0';
            json_object_set_string(result_object, "csr", (char*)csr_buffer);            
        }
    } while (false);

    // The AWS IoT Zero Touch Demo genCsr message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status process_board_application_save_credentials(JSON_Object *params_object,
                                                                           JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    
    char *certificate = NULL;
    char *signer_ca_public_key = NULL;
    char *hostname = NULL;
    uint8_t credentials_buffer[1200];
    uint16_t credentials_buffer_length = 0;
    uint8_t public_key[ATCA_PUB_KEY_SIZE];
    
    do
    {
        //Save the Signer CA public key in the ATECCx08A
        signer_ca_public_key = (char*)json_object_get_string(params_object, "signerCaPublicKey");
        if(strlen(signer_ca_public_key) > 4) 
        {
            credentials_buffer_length = strlen(signer_ca_public_key);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &signer_ca_public_key[0], credentials_buffer_length);
                        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                            credentials_buffer);
        
//             memset(&public_key[0], 0, sizeof(public_key));
//             memcpy(&public_key[0], &credentials_buffer[0], sizeof(public_key));
        signer_ca_public_key_size = sizeof(public_key);
        memcpy(g_signer_1_ca_public_key, &credentials_buffer[0], sizeof(public_key));
            //atca_status = atcab_write_pubkey(SIGNER_CA_PUBLIC_KEY_SLOT, credentials_buffer);   
        }

        // Save the Signer certificate in the ATECCx08A
        certificate = (char*)json_object_get_string(params_object, "signerCert");
        if(strlen(certificate) > 4)
        {
            credentials_buffer_length = strlen(certificate);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                           credentials_buffer);
        
            memcpy(signer_cert, credentials_buffer, credentials_buffer_length);
            signer_cert_size = credentials_buffer_length;
//             atca_status = atcacert_write_cert(&g_cert_def_1_signer, credentials_buffer,
//                                               credentials_buffer_length);
        }                                         
 
        // Save the Device certificate in the ATECCx08A
        certificate = (char*)json_object_get_string(params_object, "deviceCert");
        if(strlen(certificate) > 4)
        {
            credentials_buffer_length = strlen(certificate);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                           credentials_buffer);
        
            memcpy(device_cert, credentials_buffer, credentials_buffer_length);
            device_cert_size = credentials_buffer_length;
//             atca_status = atcacert_write_cert(&g_cert_def_2_device, credentials_buffer,
//                                           credentials_buffer_length);
        }                                          


    } while (false);

    // The AWS IoT Zero Touch Demo saveCredentials message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}
