/*
    \file   main.c

    \brief  Main source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
#include <avr/interrupt.h>

#include "kit_protocol/kit_protocol_interpreter.h"
#include "kit_protocol/kit_protocol_utilities.h"
#include "parson_json/parson.h"
#include "cryptoauthlib/lib/cryptoauthlib.h"
#include "kit_process.h"

struct kit_interpreter_interface g_kit_interpreter_interface;
static struct kit_device                g_kit_devices[1];

enum kit_protocol_status kit_board_get_version(uint8_t *message,
uint16_t *message_length)
{
    uint16_t max_message_length = kit_interpreter_get_max_message_length();

    if ((message == NULL) || (message_length == NULL))
    {
        return KIT_STATUS_INVALID_PARAM;
    }

    // Reset the returned message information
    memset(&message[0], 0, max_message_length);
    *message_length = 0;
    
    // Create the Kit Protocol Get Version response message
    sprintf((char*)&message[0], "AWS IoT Zero Touch Demo ECCx08A TWI(%02X)%c",
    g_kit_devices[0].address, KIT_MESSAGE_DELIMITER);
    
    *message_length = strlen((char*)&message[0]);

    return KIT_STATUS_SUCCESS;
}

#define VERSION_STRING_LONG "08 KIT PORT"
enum kit_protocol_status kit_board_get_firmware(uint8_t *message,
uint16_t *message_length)
{
    uint16_t max_message_length = kit_interpreter_get_max_message_length();

    if ((message == NULL) || (message_length == NULL))
    {
        return KIT_STATUS_INVALID_PARAM;
    }

    // Reset the returned message information
    memset(&message[0], 0, max_message_length);
    *message_length = 0;

    // Create the Kit Protocol Get firmware response message
    sprintf((char*)&message[0], "%s%c", VERSION_STRING_LONG, KIT_MESSAGE_DELIMITER);

    *message_length = strlen((char*)&message[0]);

    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status kit_board_get_device(uint32_t device_handle,
uint8_t *message,
uint16_t *message_length)
{
    uint16_t max_message_length = kit_interpreter_get_max_message_length();

    if ((message == NULL) || (message_length == NULL))
    {
        return KIT_STATUS_INVALID_PARAM;
    }

    // Reset the returned message information
    memset(&message[0], 0, max_message_length);
    *message_length = 0;

    // Create the Kit Protocol Get Device response message
    if (g_kit_devices[device_handle].device_id != KIT_DEVICE_ID_UNKNOWN)
    {
        sprintf((char*)&message[0], "ECCx08A TWI(%02X)%c",
        g_kit_devices[device_handle].address,
        KIT_MESSAGE_DELIMITER);
    }
    else
    {
        sprintf((char*)&message[0], "no device");
    }
    
    *message_length = strlen((char*)&message[0]);
    
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status kit_board_application(uint32_t device_handle, uint8_t *message, uint16_t *message_length)
{
    JSON_Value *command_value = NULL;
    JSON_Object *command_object = NULL;
    JSON_Object *params_object = NULL;
    
    JSON_Value *response_value = NULL;
    JSON_Object *response_object = NULL;
    JSON_Value *result_value = NULL;
    JSON_Object *result_object = NULL;
    JSON_Value *error_value = NULL;
    JSON_Object *error_object = NULL;

    uint16_t max_message_length = kit_interpreter_get_max_message_length();
    char *message_method = NULL;
    int message_id = 0;
    
//    struct aws_iot_status *aws_status = NULL;

    // Parse the incoming Board Application command message
    
    // Print the incoming AWS IoT Zero Touch command message
//     console_print_aws_message("Incoming AWS IoT Zero Touch command message:",
//     message, *message_length);
    
    command_value   = json_parse_string((char*)message);
    command_object  = json_value_get_object(command_value);
    params_object   = json_object_get_object(command_object, "params");

    response_value  = json_value_init_object();
    response_object = json_value_get_object(response_value);

    result_value    = json_value_init_object();
    result_object   = json_value_get_object(result_value);
    
    error_value     = json_value_init_object();
    error_object    = json_value_get_object(error_value);

    // Get the incoming Board Application command message method
    message_method = (char*)json_object_get_string(command_object, "method");
    // Get the incoming Board Application command message id
    message_id = json_object_get_number(command_object, "id");
    

//     // Handle the incoming AWS IoT Zero Touch command message
    if (strcmp(message_method, "init") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch Init command message
        process_board_application_init(params_object, result_object);
    }
//     else if (strcmp(message_method, "setWifi") == 0)
//     {
//         // Handle the incoming AWS IoT Zero Touch setWifi command message
//         process_board_application_set_wifi(params_object, result_object);
//     }
//     else if (strcmp(message_method, "getStatus") == 0)
//     {
//         // Handle the incoming AWS IoT Zero Touch getStatus command message
//         process_board_application_get_status(params_object, result_object);
//     }
//     else if (strcmp(message_method, "genKey") == 0)
//     {
//         // Handle the incoming AWS IoT Zero Touch genKey command message
//         process_board_application_gen_key(params_object, result_object);
//     }
//     else 
    if (strcmp(message_method, "genCsr") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch genCsr command message
        process_board_application_gen_csr(params_object, result_object);
    }
//    else 
    if (strcmp(message_method, "saveCredentials") == 0)
    {
        // Handle the incoming AWS IoT Zero Touch saveCredentials command message
        process_board_application_save_credentials(params_object, result_object);
    }
//     else if (strcmp(message_method, "resetKit") == 0)
//     {
//         // Handle the incoming AWS IoT Zero Touch resetKit command message
//         process_board_application_reset_kit(params_object, result_object);
//     }
    else
    {
        // Unknown AWS IoT Zero Touch command message
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//         AWS_STATUS_UNKNOWN_COMMAND,
//         "Unknown AWS IoT Zero Touch command message.");
//         
//         // Print the error to the console
//         console_print_aws_status("Unknown AWS IoT Zero Touch command message:",
//         aws_iot_get_status());
    }
    
    // Check for AWS IoT Zero Touch Demo status
//     aws_status = aws_iot_get_status();
//     if (aws_status->aws_status == AWS_STATUS_SUCCESS)
//     {
//         // Add the result information to the AWS IoT Zero Touch Demo response message
        json_object_set_value(response_object, "result", result_value);
        result_value = NULL;
//         
//         // No error occurred during processing of the AWS IoT Zero Touch  Demo command message
         json_object_set_null(response_object, "error");
//     }
//     else
//     {
//         // An error occurred during processing of the AWS IoT Zero Touch command message
//         json_object_set_null(response_object, "result");
// 
//         // Add the error information to the AWS IoT Zero Touch response message
//         
//         json_object_set_number(error_object, "error_code", aws_status->aws_status);
//         json_object_set_string(error_object, "error_msg", aws_status->aws_message);
// 
//         json_object_set_value(response_object, "error", error_value);
//         
//         error_value = NULL;
//     }
// 
//     // Set the outgoing AWS IoT Zero Touch response message id
     json_object_set_number(response_object, "id", message_id);
//     
//     // Save the Set the outgoing AWS IoT Zero Touch response message
    memset(&message[0], 0, max_message_length);
    *message_length = (json_serialization_size(response_value) - 1);
    json_serialize_to_buffer(response_value, (char*)message, max_message_length);
//     
//     // Print the incoming AWS IoT Zero Touch command message
//     console_print_aws_message("Outgoing AWS IoT Zero Touch response message:",
//     message, *message_length);
//     
//     // Free allocated memory
    json_value_free(command_value);
    json_value_free(error_value);
    json_value_free(result_value);
    json_value_free(response_value);

    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status kit_device_idle(uint32_t device_handle)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;

    // Send the idle command to the device
    status = atcab_idle();
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }

    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status kit_device_sleep(uint32_t device_handle)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;

    // Send the sleep command to the device
    status = atcab_sleep();
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }

    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status kit_device_wake(uint32_t device_handle)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;

    // Send the wakeup command to the device
    status = atcab_wakeup();
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }

    return KIT_STATUS_SUCCESS;
}

static uint16_t cryptoauthlib_get_execution_time(uint8_t command_opcode)
{
    uint16_t execution_time;
    ATCACommand commandObj = _gDevice->mCommands;
    
    execution_time = atGetExecTime(command_opcode, commandObj);
    
    return execution_time;
}
#include "cryptoauthlib/lib/atca_command.h"
static uint16_t cryptoauthlib_get_response_message_length(uint8_t command_opcode, uint8_t command_param1, uint16_t command_param2)
{
    uint16_t response_message_length = 0;
    ATCAPacket packet;
    ATCA_STATUS status = ATCA_GEN_FAIL;
    
    ATCACommand commandObj = _gDevice->mCommands;
    
    packet.param1 = command_param1;
    packet.param2 = command_param2;
    
    switch (command_opcode)
    {
        case ATCA_CHECKMAC:
        status = atCheckMAC(commandObj, &packet);
        break;
        
        case ATCA_DERIVE_KEY:
        status = atDeriveKey(commandObj, &packet, false);
        break;
        
        case ATCA_INFO:
        status = atInfo(commandObj, &packet);
        break;
        
        case ATCA_GENDIG:
        status = atGenDig(commandObj, &packet, false);
        break;
        
        case ATCA_GENKEY:
        status = atGenKey(commandObj, &packet);
        break;
        
        case ATCA_HMAC:
        status = atHMAC(commandObj, &packet);
        break;
        
        case ATCA_LOCK:
        status = atLock(commandObj, &packet);
        break;
        
        case ATCA_MAC:
        status = atMAC(commandObj, &packet);
        break;
        
        case ATCA_NONCE:
        status = atNonce(commandObj, &packet);
        break;
        
        case ATCA_PAUSE:
        status = atPause(commandObj, &packet);
        break;
        
        case ATCA_PRIVWRITE:
        status = atPrivWrite(commandObj, &packet);
        break;
        
        case ATCA_RANDOM:
        status = atRandom(commandObj, &packet);
        break;
        
        case ATCA_READ:
        status = atRead(commandObj, &packet);
        break;
        
        case ATCA_SIGN:
        status = atSign(commandObj, &packet);
        break;
        
        case ATCA_UPDATE_EXTRA:
        status = atUpdateExtra(commandObj, &packet);
        break;
        
        case ATCA_VERIFY:
        status = atVerify(commandObj, &packet);
        break;
        
        case ATCA_WRITE:
        status = atWrite(commandObj, &packet, false);
        break;
        
        case ATCA_ECDH:
        status = atECDH(commandObj, &packet);
        break;
        
        case ATCA_COUNTER:
        status = atCounter(commandObj, &packet);
        break;
        
        case ATCA_SHA:
        status = atSHA(commandObj, &packet, 0); //TODO this zero may be able to be handled better
        break;
        
        default:
        // Do nothing
        break;
    }

    // Set the response message length
    if (status == ATCA_SUCCESS)
    {
//        response_message_length = packet.rxsize;
    }
    else
    {
        response_message_length = ATCA_RSP_SIZE_MIN;
    }
    
    return response_message_length;
}

enum kit_protocol_status kit_device_talk(uint32_t device_handle, uint8_t *message, uint16_t *message_length)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;
    uint8_t command_opcode = 0;
    uint8_t command_param1 = 0;
    uint16_t command_param2 = 0;
    uint8_t buffer[ATCA_CMD_SIZE_MAX];
    uint16_t max_message_length = kit_interpreter_get_max_message_length();

    if ((message == NULL) || (message_length == NULL))
    {
        return KIT_STATUS_INVALID_PARAM;
    }

    // Get the command message parameters
    command_opcode = message[1];
    command_param1 = message[2];
    
    command_param2 =  (message[4] << 8);
    command_param2 |= message[3];
    
    // Copy the command message to the buffer
    memset(&buffer[0], 0, sizeof(buffer));
    memcpy(&buffer[1], &message[0], *message_length);
    
    // Send the wakeup command to the device
    status = atcab_wakeup();
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }
    
    // Send the command message to the device
    status = atsend(_gDevice->mIface, buffer, (int)*message_length);
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }
    
    // delay the appropriate amount of time for command to execute
    atca_delay_ms(cryptoauthlib_get_execution_time(command_opcode));
    
    // Reset the message information
    memset(&message[0], 0, max_message_length);
    *message_length = cryptoauthlib_get_response_message_length(command_opcode,
    command_param1,
    command_param2);
    
    // Retrieve the response message from the device
    status = atreceive(_gDevice->mIface, message, message_length);
    if (status != ATCA_SUCCESS)
    {
        return KIT_STATUS_COMM_FAIL;
    }

    return KIT_STATUS_SUCCESS;
}

static void kit_protocol_init(void)
{
    // Initialize the Kit Protocol Interpreter interface
     g_kit_interpreter_interface.board_get_version    = &kit_board_get_version;
     g_kit_interpreter_interface.board_get_firmware   = &kit_board_get_firmware;
     g_kit_interpreter_interface.board_get_device     = &kit_board_get_device;
    g_kit_interpreter_interface.board_get_devices    = NULL;
    g_kit_interpreter_interface.board_discover       = NULL;
    g_kit_interpreter_interface.board_get_last_error = NULL;
    g_kit_interpreter_interface.board_application    = (uint32_t)&kit_board_application;
    g_kit_interpreter_interface.board_polling        = NULL;
    
     g_kit_interpreter_interface.device_idle          = &kit_device_idle;
     g_kit_interpreter_interface.device_sleep         = &kit_device_sleep;
     g_kit_interpreter_interface.device_wake          = &kit_device_wake;
    g_kit_interpreter_interface.device_receive       = NULL;
    g_kit_interpreter_interface.device_send          = NULL;
    g_kit_interpreter_interface.device_talk          = &kit_device_talk;
    
    // Initialize the Kit Protocol interpreter
    kit_interpreter_init(&g_kit_interpreter_interface);
}

#define SLOT8_SIZE                (416)
#define SLOT8_SSID_SIZE           (32)
#define SLOT8_WIFI_PASSWORD_SIZE  (64)
#define SLOT8_HOSTNAME_SIZE       (128)
#define METADATA_SLOT              (8)

struct Eccx08A_Slot8_Metadata
{
    uint32_t provision_flag;             //! Flag to tell if the ATECCx08A is provisioned
    uint32_t ssid_size;
    uint8_t  ssid[SLOT8_SSID_SIZE];
    uint32_t wifi_password_size;
    uint8_t  wifi_password[SLOT8_WIFI_PASSWORD_SIZE];
    uint32_t hostname_size;
    uint8_t  hostname[SLOT8_HOSTNAME_SIZE];
};
ATCA_STATUS provisioning_get_ssid(uint32_t *ssid_length, char *ssid)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t metadata_buffer[SLOT8_SIZE];
    struct Eccx08A_Slot8_Metadata metadata;
    
    if ((ssid_length == NULL) || (ssid == NULL))
    {
        return ATCA_BAD_PARAM;
    }
    
    // Get the AWS Provisioning WIFI SSID from the ATECCx08A
    do
    {
        // Get the AWS Provisioning WIFI SSID
        if (*ssid_length >= SLOT8_SSID_SIZE)
        {
            memset(&metadata_buffer[0], 0, sizeof(metadata_buffer));
            atca_status = atcab_read_bytes_zone(ATCA_ZONE_DATA, METADATA_SLOT, 0,
            metadata_buffer, sizeof(metadata_buffer));
            if (atca_status == ATCA_SUCCESS)
            {
                // Get the AWS Provisioning WIFI SSID
                memcpy(&metadata, &metadata_buffer[0], sizeof(metadata));

                memset(&ssid[0], 0, *ssid_length);
                memcpy(&ssid[0], &metadata.ssid[0], metadata.ssid_size);
                *ssid_length = metadata.ssid_size;
            }
            else
            {
                *ssid_length = 0;
            }
        }
        else
        {
            atca_status = ATCA_INVALID_SIZE;
            *ssid_length = 0;
        }
    } while (false);
    
    return atca_status;
}

void USART_0_write_string(char * str)
{
    for(uint32_t i = 0; i < strlen(str); i++)
    {
        USART_0_write(str[i]);
    }
}

void kit_com_write_string(char * str)
{
    for(uint32_t i = 0; i <= strlen(str); i++)
    {
        kit_com_write(str[i]);
    }
}

uint32_t idx = 0;
char *method;   
char *param_field;  
JSON_Value *val;
JSON_Object *val_obj, *params;
int main(void)
{	
	sei();
	atmel_start_init();
    
    kit_protocol_init();
    cryptoauthlib_init();
    
    char ssid[SLOT8_SSID_SIZE];
    uint8_t ssid_length = sizeof(ssid);
    provisioning_get_ssid(&ssid_length, ssid);
    
    USART_0_write_string("SSID IN ATECC: ");
    USART_0_write_string(ssid);
    USART_0_write_string("\r\n");
    
    uint8_t uart_buffer[KIT_MESSAGE_SIZE_MAX];
    char c;     
    idx = 0;
	while (1) 
	{
        c = USART_0_read();	
        if(c != '\n')
        {
            uart_buffer[idx++] = c;
        }
        else
        {
            uart_buffer[idx++] = '\n';
            uart_buffer[idx++] = '\0';
            
//             val = json_parse_string(uart_buffer);
//             val_obj = json_value_get_object(val);
//             method = (char*) json_object_get_string(val_obj, "method");
//             
//             params = json_object_get_object(val_obj, "params");
// //             param_field = (char*) json_object_get_string(params, "deviceCert");
// //             kit_protocol_write_device_cert(param_field);
//             param_field = (char*) json_object_get_string(params, "signerCert");
//             kit_protocol_write_signer_cert(param_field);
            


            //kit_interpreter_handle_message(uart_buffer, &idx);
            kit_board_application(NULL, uart_buffer,&idx);
            
            
            //kit_com_write_string(uart_buffer);
            USART_0_write_string(uart_buffer);
            kit_protocol_init();
            idx = 0;    
        }	
        USART_0_write(c);
	}
	
	return 0;
}
