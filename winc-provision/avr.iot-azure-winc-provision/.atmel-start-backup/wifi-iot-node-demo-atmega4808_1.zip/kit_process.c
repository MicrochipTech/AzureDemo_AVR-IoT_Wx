#define DEVICE_KEY_SLOT            (0)

#include <stdint.h>
#include "parson_json/parson.h"
#include "kit_protocol/kit_protocol_interpreter.h"
#include "cryptoauthlib/lib/cryptoauthlib.h"
#include "cert_def_3_device_csr.h"

enum kit_protocol_status process_board_application_init(JSON_Object *params_object,
                                                               JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t serial_number[ATCA_SERIAL_NUM_SIZE];
    uint8_t public_key[ATCA_PUB_KEY_SIZE];
    char ascii_buffer[150];
    
    do 
    {
        // Set the successful AWS IoT Zero Touch Demo status
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                            AWS_STATUS_SUCCESS,
//                            "The AWS IoT Demo successfully performed the initialization.");

        // Get the ATECCx08A device serial number
        memset(&serial_number[0], 0, sizeof(serial_number));
        atca_status = atcab_read_serial_number(serial_number);
        if (atca_status == ATCA_SUCCESS)
        {
            // Save the ATECCx08A device serial number
            memset(&ascii_buffer[0], 0, sizeof(ascii_buffer));
            memcpy(&ascii_buffer[0], &serial_number[0], sizeof(serial_number));
        
            kit_protocol_convert_binary_to_hex(sizeof(serial_number), 
                                               (uint8_t*)ascii_buffer);
            json_object_set_string(result_object, "deviceSn", ascii_buffer);
        }
        else
        {
            // The ECCx08A failed to return the serial number
//             aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE, 
//                                AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                                "The AWS IoT Demo failed to return the serial number.");
//                                    
//             // Print the status to the console
//             console_print_aws_status("AWS IoT Zero Touch Demo init Message:",
//                                      aws_iot_get_status());
                                    
            // Break the do/while loop
            break;        
        }    


        // Get the ATECCx08A device public key
        memset(&public_key[0], 0, sizeof(public_key));
        atca_status = atcab_genkey_base(GENKEY_MODE_PUBLIC, DEVICE_KEY_SLOT, 
                                        NULL, public_key);
        if (atca_status == ATCA_SUCCESS)
        {
            // Save the ATECCx08A device public key
            memset(&ascii_buffer[0], 0, sizeof(ascii_buffer));
            memcpy(&ascii_buffer[0], &public_key[0], sizeof(public_key));
            
            kit_protocol_convert_binary_to_hex(sizeof(public_key), 
                                               (uint8_t*)ascii_buffer);
            json_object_set_string(result_object, "devicePublicKey", ascii_buffer);
        }
        else
        {
//             // The ECCx08A failed to return the device public key
//             aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                                AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                                "The AWS IoT Demo failed to return the device public key.");
//         
//             // Print the status to the console
//             console_print_aws_status("AWS IoT Zero Touch Demo init Message:",
//                                      aws_iot_get_status());
        
            // Break the do/while loop
            break;
        }
    } while (false);
    
    // The AWS IoT Zero Touch Demo init message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
};


#define SLOT8_SIZE                (416)
#define SLOT8_SSID_SIZE           (32)
#define SLOT8_WIFI_PASSWORD_SIZE  (64)
#define SLOT8_HOSTNAME_SIZE       (128)
#define METADATA_SLOT              (8)
#define SLOT8_WIFI_PROVISIONED_VALUE   (0x72B0)  //! Value to determine if the ATECCx08A is provisioned with wifi credentials

struct Eccx08A_Slot8_Metadata
{
    uint32_t provision_flag;             //! Flag to tell if the ATECCx08A is provisioned
    uint32_t ssid_size;
    uint8_t  ssid[SLOT8_SSID_SIZE];
    uint32_t wifi_password_size;
    uint8_t  wifi_password[SLOT8_WIFI_PASSWORD_SIZE];
    uint32_t hostname_size;
    uint8_t  hostname[SLOT8_HOSTNAME_SIZE];
};

enum kit_protocol_status process_board_application_set_wifi(JSON_Object *params_object,
                                                                   JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    char *ssid = NULL;
    char *password = NULL;

    struct Eccx08A_Slot8_Metadata metadata;
    uint8_t metadata_buffer[SLOT8_SIZE];

    do
    {
        // Set the successful AWS IoT Zero Touch Demo status
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                            AWS_STATUS_SUCCESS,
//                            "The AWS IoT Demo successfully saved the WIFI credentials.");

        // Save the WIFI credentials in the ATECCx08A
        memset(&metadata_buffer[0], 0, sizeof(metadata_buffer));
        atca_status = atcab_read_bytes_zone(ATCA_ZONE_DATA, METADATA_SLOT, 0,
                                            metadata_buffer, sizeof(metadata_buffer));
        if (atca_status != ATCA_SUCCESS)
        {
            // Break the do/while loop
            break;
        }

        ssid = (char*)json_object_get_string(params_object, "ssid");
        password = (char*)json_object_get_string(params_object, "psk");

        memcpy(&metadata, &metadata_buffer[0], sizeof(struct Eccx08A_Slot8_Metadata));

        memset(&(metadata.ssid)[0], 0, sizeof(metadata.ssid));
        memcpy(&(metadata.ssid)[0], &ssid[0], strlen(ssid));
        metadata.ssid_size = strlen(ssid);
        
        if (password != NULL)
        {
            memset(&(metadata.wifi_password)[0], 0, sizeof(metadata.wifi_password));
            memcpy(&(metadata.wifi_password)[0], &password[0], strlen(password));
            metadata.wifi_password_size = strlen(password);
        }
        else
        {
            memset(&(metadata.wifi_password)[0], 0, sizeof(metadata.wifi_password));
            metadata.wifi_password_size = 0;
        }        

        // Set the ATECCx08A device provisioned flag
        metadata.provision_flag = (metadata.provision_flag & 0xFFFF0000) + ((uint32_t)SLOT8_WIFI_PROVISIONED_VALUE);

        // Save the metadata to the ATECCx08A
        memset(&metadata_buffer[0], 0, sizeof(metadata_buffer));
        memcpy(&metadata_buffer[0], &metadata, sizeof(metadata));
        atca_status = atcab_write_bytes_zone(ATCA_ZONE_DATA, METADATA_SLOT, 0,
                                             metadata_buffer, sizeof(metadata_buffer));
    } while (false);

    if (atca_status != ATCA_SUCCESS)
    {
        // The ECCx08A failed to save the WIFI credentials in the ATECCx08A
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                            AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                            "The AWS IoT Demo failed to save the WIFI credentials.");
//             
//         // Print the status to the console
//         console_print_aws_status("AWS IoT Zero Touch Demo saveCredentials Message:",
//                                  aws_iot_get_status());
    }

    // The AWS IoT Zero Touch Demo setWifi message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status process_board_application_get_status(JSON_Object *params_object,
                                                                     JSON_Object *result_object)
{
//     struct aws_iot_status *status = aws_iot_get_status(); 
// 
//     // Set the successful AWS IoT Zero Touch Demo status
//     aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                        AWS_STATUS_SUCCESS,
//                        "The AWS IoT Demo successfully returned the current status information.");
    
    // Return the current AWS IoT Zero Touch Demo status
    char test[] = "test";
    json_object_set_number(result_object, "state_id", 1);
    json_object_set_number(result_object, "status_code", 1);
    json_object_set_string(result_object, "status_msg", test);

    // The AWS IoT Zero Touch Demo genKey message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status process_board_application_gen_key(JSON_Object *params_object,
                                                                  JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t public_key[ATCA_PUB_KEY_SIZE];
    char ascii_buffer[150];

    uint8_t metadata_buffer[SLOT8_SIZE];

    do
    {
        // Set the successful AWS IoT Zero Touch Demo status
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                            AWS_STATUS_SUCCESS,
//                            "The AWS IoT Demo successfully generated the device ECC-p256 key pair.");

        // Generate a new ATECCx08A Device ECC-p256 key pair
        memset(&public_key[0], 0, sizeof(public_key));
        atca_status = atcab_genkey(DEVICE_KEY_SLOT, public_key);
        if (atca_status == ATCA_SUCCESS)
        {
            // Save the ATECCx08A device public key
            memset(&ascii_buffer[0], 0, sizeof(ascii_buffer));
            memcpy(&ascii_buffer[0], &public_key[0], sizeof(public_key));
            
            kit_protocol_convert_binary_to_hex(sizeof(public_key),
                                               (uint8_t*)ascii_buffer);
            json_object_set_string(result_object, "devicePublicKey", ascii_buffer);
        }
        else
        {
            // The ECCx08A failed to return the device public key
//             aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                                AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                                "The AWS IoT Demo failed to create the device ECC-p256 key pair.");
//             
//             // Print the status to the console
//             console_print_aws_status("AWS IoT Zero Touch Demo genKey Message:",
//                                      aws_iot_get_status());
            
            // Break the do/while loop
            break;
        }
        

        // Reset the credentials information in the ATECCx08A
        do
        {
            memset(&metadata_buffer[0], 0, sizeof(metadata_buffer));            
            atca_status = atcab_write_bytes_zone(ATCA_ZONE_DATA, METADATA_SLOT, 0,
                                                 metadata_buffer, sizeof(metadata_buffer));
        } while (false);

        if (atca_status == ATCA_SUCCESS)
        {
            // Do nothing
        }
        else
        {
            // The ECCx08A failed to generate a new ATECCx08A Device ECC-p256 key pair
//             aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                                AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                                "The AWS IoT Demo failed to reset the credentials information.");
//             
//             // Print the status to the console
//             console_print_aws_status("AWS IoT Zero Touch Demo genKey Message:",
//                                      aws_iot_get_status());
            
            // Break the do/while loop
            break;
        }        
    } while (false);
    
    
    /**
     * The credentials are invalid, reset the AWS IoT Zero Touch Demo to 
     * accept a new provisioned configuration
     */
    //g_provisioning_state = AWS_STATE_ATECCx08A_PROVISION_RESET;

    // The AWS IoT Zero Touch Demo genKey message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status process_board_application_gen_csr(JSON_Object *params_object,
                                                                  JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t csr_buffer[1500];
    size_t csr_buffer_length = 0;
    
    do
    {
        // Set the successful AWS IoT Zero Touch Demo status
//         aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                            AWS_STATUS_SUCCESS,
//                            "The AWS IoT Demo successfully generated the device CSR.");
        
        // Generate the AWS IoT device CSR
        csr_buffer_length = sizeof(csr_buffer);
        atca_status = atcacert_create_csr(&g_csr_def_3_device, csr_buffer, 
                                          &csr_buffer_length);
        
        if (atca_status == ATCA_SUCCESS)
        {
            kit_protocol_convert_binary_to_hex((uint16_t)csr_buffer_length, 
                                               csr_buffer);
            csr_buffer[2 * csr_buffer_length] = '\0';
            json_object_set_string(result_object, "csr", (char*)csr_buffer);            
        }
        else
        {
            // The ECCx08A failed to generate the device CSR
//             aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                                AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                                "The AWS IoT Demo failed to generate the device CSR.");
//             
//             // Print the status to the console
//             console_print_aws_status("AWS IoT Zero Touch Demo genCsr Message:",
//                                      aws_iot_get_status());
//             
            // Break the do/while loop
            break;
        }            
    } while (false);

    // The AWS IoT Zero Touch Demo genCsr message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

#define SLOT8_AWS_PROVISIONED_VALUE    (0xF309) 
#define SIGNER_CA_PUBLIC_KEY_SLOT  (15)
#include "cert_def_1_signer.h"
#include "cert_def_2_device.h"

ATCA_STATUS kit_protocol_write_device_cert(char *certificate)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t credentials_buffer[1200];
    uint16_t credentials_buffer_length = 0;
    
   /* certificate = (char*)json_object_get_string(params_object, "deviceCert");*/
    credentials_buffer_length = strlen(certificate);
    memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
    memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
    
    credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
    credentials_buffer);
    
    atca_status = atcacert_write_cert(&g_cert_def_2_device, credentials_buffer, credentials_buffer_length);
    
    return atca_status;
}

ATCA_STATUS kit_protocol_write_signer_cert(char *certificate)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t credentials_buffer[1200];
    uint16_t credentials_buffer_length = 0;

    credentials_buffer_length = strlen(certificate);
    memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
    memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
        
    credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                    credentials_buffer);
        
    atca_status = atcacert_write_cert(&g_cert_def_1_signer, credentials_buffer, credentials_buffer_length);
    
    return atca_status;
}
ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
enum kit_protocol_status process_board_application_save_credentials(JSON_Object *params_object,
                                                                           JSON_Object *result_object)
{
    
    char *certificate = NULL;
    char *signer_ca_public_key = NULL;
    char *hostname = NULL;
    uint8_t credentials_buffer[1200];
    uint16_t credentials_buffer_length = 0;
    uint8_t public_key[ATCA_PUB_KEY_SIZE];
    
    struct Eccx08A_Slot8_Metadata metadata;
    uint8_t metadata_buffer[SLOT8_SIZE];
    
    do
    {
        

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Save the Signer CA public key in the ATECCx08A
        signer_ca_public_key = (char*)json_object_get_string(params_object, "signerCaPublicKey");
        if(strlen(signer_ca_public_key) > 4) 
        {
            credentials_buffer_length = strlen(signer_ca_public_key);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &signer_ca_public_key[0], credentials_buffer_length);
                        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                            credentials_buffer);
        
            memset(&public_key[0], 0, sizeof(public_key));
            memcpy(&public_key[0], &credentials_buffer[0], sizeof(public_key));
        
            atca_status = atcab_write_pubkey(SIGNER_CA_PUBLIC_KEY_SLOT, credentials_buffer);   
        }
        
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        
         // Save the Signer certificate in the ATECCx08A
        certificate = (char*)json_object_get_string(params_object, "signerCert");
        if(strlen(certificate) > 4)
        {
            credentials_buffer_length = strlen(certificate);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                           credentials_buffer);
        
            atca_status = atcacert_write_cert(&g_cert_def_1_signer, credentials_buffer,
                                              credentials_buffer_length);
        }                                         
// 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Save the Device certificate in the ATECCx08A
        certificate = (char*)json_object_get_string(params_object, "deviceCert");
        if(strlen(certificate) > 4)
        {
            credentials_buffer_length = strlen(certificate);
            memset(&credentials_buffer[0], 0, sizeof(credentials_buffer));
            memcpy(&credentials_buffer[0], &certificate[0], credentials_buffer_length);
        
            credentials_buffer_length = kit_protocol_convert_hex_to_binary(credentials_buffer_length,
                                                                           credentials_buffer);
        
            atca_status = atcacert_write_cert(&g_cert_def_2_device, credentials_buffer,
                                          credentials_buffer_length);
        }                                          


    } while (false);

    // The AWS IoT Zero Touch Demo saveCredentials message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}

enum kit_protocol_status process_board_application_reset_kit(JSON_Object *params_object,
                                                                    JSON_Object *result_object)
{
    ATCA_STATUS atca_status = ATCA_STATUS_UNKNOWN;
    uint8_t metadata_buffer[SLOT8_SIZE];

    // Set the successful AWS IoT Zero Touch Demo status
//     aws_iot_set_status(AWS_STATE_ATECCx08A_CONFIGURE,
//                        AWS_STATUS_SUCCESS,
//                        "The AWS IoT Demo successfully reset the kit information.");

    // Reset the credentials information in the ATECCx08A
    memset(&metadata_buffer[0], 0, sizeof(metadata_buffer));
    atca_status = atcab_write_bytes_zone(ATCA_ZONE_DATA, METADATA_SLOT, 0,
                                            metadata_buffer, sizeof(metadata_buffer));
    if (atca_status != ATCA_SUCCESS)
    {
        // The ECCx08A failed to reset the credentials information
//         aws_iot_set_status(AWS_STATE_ATECCx08A_PROVISION_RESET,
//                            AWS_STATUS_ATECCx08A_COMM_FAILURE,
//                            "The AWS IoT Demo failed to reset the kit information.");
//             
//         // Print the error to the console
//         console_print_aws_status("AWS IoT Zero Touch Demo genKey Message:",
//                                  aws_iot_get_status());
    }


    // Reset the AWS IoT Zero Touch Demo to accept a new provisioned configuration
//     g_provisioning_state = AWS_STATE_ATECCx08A_PROVISION_RESET;
// 
//     console_print_warning_message("The ATECCx08A device has not been provisioned. Waiting ...");

    // The AWS IoT Zero Touch Demo genKey message will always return KIT_STATUS_SUCCESS
    return KIT_STATUS_SUCCESS;
}