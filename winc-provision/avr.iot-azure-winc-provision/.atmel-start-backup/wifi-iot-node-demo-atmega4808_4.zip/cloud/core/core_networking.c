/*
    \file   core_networking.c

    \brief  Core networking source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/  

#include "../mqtt_packetPopulation/mqtt_packetPopulate.h"
#include "../credentials_storage/credentials_storage.h"
#include "core.h"
#include "core_networking.h"

#define MAIN_WIFI_M2M_BUFFER_SIZE		48
uint8_t socketBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];

void CORE_NETWORKING_wifiHandler(uint8_t msgType, void *pMsg)
{
    tstrM2MProvisionInfo *pstrProvInfo;
    tstrM2mWifiStateChanged *pstrWifiState;
    
    switch (msgType) 
    {
        case M2M_WIFI_REQ_DHCP_CONF:
            CORE_receiveEvent(CORE_NETWORK_AVAILABLE_E);
            break;
        case M2M_WIFI_RESP_PROVISION_INFO:
            pstrProvInfo = (tstrM2MProvisionInfo*)pMsg;
            if (pstrProvInfo->u8Status == M2M_SUCCESS) 
            {
                CREDENTIALS_STORAGE_receive(pstrProvInfo);
            }
            break;
        case M2M_WIFI_RESP_CON_STATE_CHANGED:
            pstrWifiState = (tstrM2mWifiStateChanged*)pMsg;
            if (pstrWifiState->u8CurrState == M2M_WIFI_DISCONNECTED) {
                CORE_receiveEvent(CORE_LOST_WIFI_E);
            }
            break;
        default:
            break;
    }
}

void CORE_NETWORKING_socketHandler(SOCKET sock, uint8_t msgType, void *pMsg)
{
    tstrSocketRecvMsg *pstrRecv;
    tstrSocketConnectMsg *pstrConnect;
    
    switch (msgType) 
    {
        case SOCKET_MSG_CONNECT:
            pstrConnect = (tstrSocketConnectMsg *)pMsg;
            if (pstrConnect && pstrConnect->s8Error >= 0) 
            {
                CORE_receiveEvent(CORE_SERVER_ACCEPTED_CONNECTION_E);
            } 
            else 
            {
                CORE_receiveEvent(CORE_SERVER_CLOSED_CONNECTION_E);
                close(sock);
            }
            break;

        case SOCKET_MSG_SEND:
            recv(tcpClientSocket, socketBuffer, sizeof(socketBuffer), 0);
            break;

        case SOCKET_MSG_RECV:
            pstrRecv = (tstrSocketRecvMsg *)pMsg;
            if (pstrRecv && pstrRecv->s16BufferSize > 0) 
            {
                MQTT_CLIENT_receive(pstrRecv->pu8Buffer, pstrRecv->s16BufferSize);
            } 
            else 
            {
                CORE_receiveEvent(CORE_SERVER_CLOSED_CONNECTION_E);
                close(tcpClientSocket);
                tcpClientSocket = -1;
            }
            break;
        
        default:
            break;
    }
}

void CORE_NETWORKING_dnsHandler(uint8* domainName, uint32 serverIP)
{
    if(serverIP != 0) {
        mqttGoogleApisComIP = serverIP;
        CORE_receiveEvent(CORE_OBTAIN_IP_SUCCESS_E);
    } else {
        CORE_receiveEvent(CORE_OBTAIN_IP_FAILED_E);
    }
}
