/*
    \file   cloud.c

    \brief  Cloud Application Main source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <string.h>
#include "core/core_actions.h"
#include "atmel_start_pins.h"
#include "timeout.h"
#include "../winc/driver/include/m2m_wifi.h"
#include "cli/cli.h"
#include "mqtt_packetPopulation/mqtt_packetPopulate.h"
#include "cloud.h"

#define CLOUD_CLI

static void (*notifyObserver)(cloudState_t);

void CLOUD_init(void) 
{
    LED_RED_set_level(true);
    LED_GREEN_set_level(true);
    LED_BLUE_set_level(true);
#ifdef CLOUD_CLI
CLI_init();
#endif
    CORE_initStateMachine();
    CORE_firstAction();
}

void CLOUD_task(void)
{
    m2m_wifi_handle_events(NULL);
    
#ifdef CLOUD_CLI
CLI_task();
#endif
    
    scheduler_timeout_call_next_callback();
    
    CORE_handleEvents();
    
    if(notifyObserver != NULL)
    {
        notifyObserver(CLOUD_getState());
    }
}

void CLOUD_send(uint8_t *data, uint8_t datalen)
{
    MQTT_CLIENT_publish(data);
}

void CLOUD_registerObserver(void *f)
{
    notifyObserver = f;	
}

cloudState_t CLOUD_getState(void)
{
    switch(CORE_getState())
    {
        case CORE_CONNECTED_S:
            return CLOUD_CONNECTED_S;
        case CORE_STOP_S:
            return CLOUD_STOPPED_S;
        default:
            return CLOUD_CONNECTING_S;
    }
}
