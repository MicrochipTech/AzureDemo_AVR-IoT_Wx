/********************************************************************
 *
 � [2018] Microchip Technology Inc. and its subsidiaries.

   Subject to your compliance with these terms, you may use Microchip software  
 * and any derivatives exclusively with Microchip products. It is your 
 * responsibility to comply with third party license terms applicable to your 
 * use of third party software (including open source software) that may 
 * accompany Microchip software.
   THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER  
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR 
 * PURPOSE.
 * 
   IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN 
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, 
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *************************************************************************
 *
 *                           mqtt_client.c
 *
 * About:
 *  MQTT client implementation. This is the core of the MQTT client protocol
 *  implementation. The aim of this file is to implement a hardware-independent 
 *  subsystem that complies with [mqtt-v3.1.1-plus-errata01]. 
 *
 * 
 ******************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "timeout.h"
#include "mqtt_client.h"


/***********************MQTT Client definitions********************************/

#define MQTT_TX_PACKET_DECISION_CONSTANT    0x01
#define KEEP_ALIVE_CALCULATION_CONSTANT     0x01
#define CONNECT_CLEAN_SESSION_MASK          0x02
#define TOPIC_SIZE                          100
#define PAYLOAD_SIZE                        200


// MQTT packet CONNACK return codes. These are defined in the MQTT documentation
// and indicate the success/ failure of establishing a connection with the 
// broker.
typedef enum
{
    CONN_ACCEPTED                     = 0,
    CONN_REFUSED_PROTOCOL_VER         = 1,
    CONN_REFUSED_ID_REJECTED          = 2,
    CONN_REFUSED_SERV_UNAVAILABLE     = 3,
    CONN_REFUSED_USERNAME_OR_PASSWORD = 4,
    CONN_REFUSED_NOT_AUTHORIZED       = 5
} connectReturnCode;


// MQTT packet transmission flags. The creation and transmission processes of 
// MQTT control packets uses a set of flags to indicate that a new packet is 
// created and available for transmission. These flags are defined here.
typedef union
{
    uint8_t All;
    struct
    {  
        unsigned newTxConnectPacket                 : 1;    // Indicates new CONNECT packet available for transmission
        unsigned newTxDisconnectPacket              : 1;    // Indicates new DISCONNECT packet available for transmission
        unsigned newTxPublishPacket                 : 1;    // Indicates new PUBLISH packet available for transmission
        unsigned newTxSubscribePacket               : 1;    // Indicates new SUBSCRIBE packet available for transmission
        unsigned newTxUnsubscribePacket             : 1;    // Indicates new UNSUBSCRIBE packet available for transmission
        unsigned newTxPingreqPacket                 : 1;    // Indicates new PINGREQ packet available for transmission
        unsigned                                    : 2;    // Reserved
    };
} newTxDataFlags;


// MQTT packet reception flags. The reception processes of MQTT control packets
// uses a set of flags to identify the received packet type in order to 
// correctly process it. These flags are defined here.
typedef union
{
    uint8_t All;
    struct
    {  
        unsigned newRxConnackPacket                 : 1;    // Indicates new CONNACK packet has been received
        unsigned newRxPublishPacket                 : 1;    // Indicates new PUBLISH packet has been received
        unsigned newRxSubackPacket                  : 1;    // Indicates new SUBACK packet has been received
        unsigned newRxUnsubackPacket                : 1;    // Indicates new UNSUBACK packet has been received
        unsigned newRxPingrespPacket                : 1;    // Indicates new PINGRESP packet has been received
        unsigned                                    : 3;    // Reserved
    };
} newRxDataFlags;


// MQTT packet transmission states. The transmission of MQTT control packets is 
// performed inside the CONNECTED state. The Tx state machine states are defined 
// here. These need to correspond to the respective flags in the union 
// newTxDataFlags.
typedef enum
{    
    SENDDISCONNECT = 2,
    SENDPUBLISH = 4,
    SENDSUBSCRIBE = 8,     
    SENDUNSUBSCRIBE = 16,    
    SENDPINGREQ = 32,       
}mqttConnectCurrentTxSubstate;

// MQTT SUBACK return codes are defined in MQTT documentation. The return code indicates the success/failure 
// and QoS level in case of success. The order of return codes must match the order of Topic Filters.
typedef enum
{
	SUBSCRIBE_SUCCESS_QoS0 = 0x00,
	SUBSCRIBE_SUCCESS_QoS1 = 0x01,
	SUBSCRIBE_SUCCESS_QoS2 = 0x02,
	SUBSCRIBE_FAILURE      = 0x80,		
} subscribeAckReturnCode;

// Function pointer for handling QoS levels.
typedef void (*qosLevelHandler)(uint8_t); 


// The QoS levels in PUBLISH message are 0, 1 and 2 with quality of service 
// increasing from QoS level 0 to 2. QoS level processing needs information 
// about the QoS level and the appropriate callback function. The call back 
// table type for determining whether the correct callback function for the QoS 
// level under consideration is defined here.
typedef struct
{
    uint8_t qosLevel;
    qosLevelHandler qosLevelHandlerFunction;
} qosLevelHandler_t;

/***********************MQTT Client definitions*(END)**************************/


/***********************MQTT Client variables**********************************/

/** \brief MQTT packet transmission flags. */
static newTxDataFlags mqttTxFlags; 


/** \brief MQTT packet reception flags. */
static newRxDataFlags mqttRxFlags;


/** \brief CONNECT packet to be transmitted. */
static mqttConnectPacket txConnectPacket;


/** \brief PUBLISH packet to be transmitted. */
static mqttPublishPacket txPublishPacket;

/** \brief SUBSCRIBE packet to be transmitted. */
static mqttSubscribePacket txSubscribePacket;

/** \brief CONNACK packet timeout indicator. */
static volatile bool connackTimeoutOccured = false;


/** \brief PINGREQ packet timeout indicator. */
static volatile bool pingreqTimeoutOccured = false;


/** \brief PINGRESP packet timeout indicator. */
static volatile bool pingrespTimeoutOccured = false;


/** \brief QoS level call back table.
 *
 * This callback table lists the callback functions for 3 different QoS levels
 * of the MQTT PUBLISH message. For each QoS level there needs to be a   
 * corresponding callback function.
 * Currently only QoS level 0 is supported.
 * 
 */
static const qosLevelHandler_t mqtt_qosLevelCallBackTable[] = 
{
//    {0x00, handleQoSLevel0}
};


/** \brief Current state of MQTT Client state machine. */
static mqttCurrentState mqttState = DISCONNECTED;


/** \brief Tx substate for the state machine inside the CONNECTED state. */
static mqttConnectCurrentTxSubstate mqttConnectTxSubstate;


/** \brief Indicator for reinitialisation of TCP connection. */
static bool tcpClientSocketStatus = false;

/***********************MQTT Client variables*(END)****************************/
    

/**********************Local function definitions******************************/

/** \brief Encode the MQTT packet length.
 *
 * This function encodes the MQTT packet length.
 *
 * @param length
 * @param *output 
 * 
 * @return
 *  - The number of bytes encoded
 */
static uint8_t mqttEncodeLength(uint16_t length, uint8_t *output);


/** \brief Send the MQTT CONNECT packet.
 *
 * This function sends the MQTT CONNECT packet using the underlying
   TCP layer.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The return code indicating success/failure of CONNECT packet 
	  transmission.
 */
static bool mqttSendConnect(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Send the MQTT PUBLISH packet.
 *
 * This function sends the MQTT PUBLISH packet using the underlying
   TCP layer.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The return code indicating success/failure of PUBLISH packet 
	  transmission.
 */
static bool mqttSendPublish(mqttTxRxInformation *mqttConnectionPtr);

/** \brief Send the MQTT SUBSCRIBE packet.
 *
 * This function sends the MQTT SUBSCRIBE packet using the underlying
   TCP layer.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The return code indicating success/failure of SUBSCRIBE packet 
	  transmission.
 */
static bool mqttSendSubscribe(mqttTxRxInformation *mqttConnectionPtr);

/** \brief Send the MQTT PINGREQ packet.
 *
 * This function sends the MQTT PINGREQ packet using the underlying
   TCP layer.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The return code indicating success/failure of PINGREQ packet 
	  transmission.
 */
static bool mqttSendPingreq(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Send the MQTT DISCONNECT packet.
 *
 * This function sends the MQTT DISCONNECT packet using the underlying
   TCP layer.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The return code indicating success/failure of DISCONNECT packet 
	  transmission.
 */
static bool mqttSendDisconnect(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Process the MQTT CONNACK packet.
 *
 * This function processes the CONNACK packet received from the 
    broker.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The state of MQTT Tx and Rx handlers depending on whether the CONNACK
      packet was received and processed correctly.
 */
static mqttCurrentState mqttProcessConnack(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Process the MQTT PINGRESP packet.
 *
 * This function processes the PINGRESP packet received from the 
    broker.
 *
 * @param mqttConnectionPtr
 * 
 */
static void mqttProcessPingresp(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Process the MQTT SUBACK packet.
 *
 * This function processes the SUBACK packet received from the 
    broker.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The state of MQTT Tx and Rx handlers depending on whether the mqttProcessSuback
      packet was received and processed correctly.
 */
static mqttCurrentState mqttProcessSuback(mqttTxRxInformation *mqttConnectionPtr);

/** \brief Process the MQTT PUBLISH packet.
 *
 * This function processes the PUBLISH packet received from the 
    broker.
 *
 * @param mqttConnectionPtr
 * 
 * @return
 *  - The state of MQTT Tx and Rx handlers depending on whether the mqttProcessPublish
      packet was received and processed correctly.
 */
static mqttCurrentState mqttProcessPublish(mqttTxRxInformation *mqttConnectionPtr);


/** \brief Get the reinitialisation status of the underlying TCP socket .
 *
 * This function returns the status of whether the the TCP socket connection
   used for MQTT packet handling has been reinitialised or not. 
 * 
 * @return
 *  - The reinitialisation status of TCP socket connection used MQTT packet 
      handling .
 */
static bool mqttGetTCPConnReinitialisationStatus(void);


/** \brief Check whether timeout has occurred after sending CONNECT
    packet.
 *
 * This function checks whether a timeout (30s) has occurred after sending
   CONNECT packet, since a CONNACK packet is expected from the broker
   within 30s.
 *
 * @param none
 * 
 * @return
 *  - The number of ticks till the connackTimer expires.
 */
static absolutetime_t checkConnackTimeoutState();
timerstruct_t connackTimer = {checkConnackTimeoutState, NULL};


/** \brief Check whether timeout has occurred after receiving CONNACK
    or PINGRESP packet.
 *
 * This function checks whether a timeout of (keepAliveTime)s has occurred after  
   receiving CONNACK or PINGRESP packet, since a client is expected to send some
   packet to the broker within (keepAliveTime)s time period.
 *
 * @param none
 * 
 * @return
 *  - The number of ticks till the connackTimer or pingrespTimer expires.
 */
static absolutetime_t checkPingreqTimeoutState();
timerstruct_t pingreqTimer = {checkPingreqTimeoutState, NULL};


/** \brief Check whether timeout has occurred after sending PINGREQ
    packet.
 *
 * This function checks whether a timeout (30s) has occurred after sending
   PINGREQ packet. In the current MQTT client implementation, the client
   waits for 30s after transmission of PINGREQ packet to receive a PINGRESP 
   packet.
 *
 * @param none
 * 
 * @return
 *  - The number of ticks till the pingreq expires.
 */
static absolutetime_t checkPingrespTimeoutState();
timerstruct_t pingrespTimer = {checkPingrespTimeoutState, NULL};

/**********************Local function definitions*(END)************************/


/**********************Function implementations********************************/

static absolutetime_t checkConnackTimeoutState()
{
	connackTimeoutOccured = true;	// Mark that timer has executed
	return 0;	// Stop the timer
}


static absolutetime_t checkPingreqTimeoutState()
{
	pingreqTimeoutOccured = true;	// Mark that timer has executed
    return ((ntohs(txConnectPacket.connectVariableHeader.keepAliveTimer) - KEEP_ALIVE_CALCULATION_CONSTANT) * SECONDS);
}


static absolutetime_t checkPingrespTimeoutState()
{
	pingrespTimeoutOccured = true;	// Mark that timer has executed
    return (WAITFORPINGRESP_TIMEOUT);
}


static bool mqttGetTCPConnReinitialisationStatus(void)
{
	return tcpClientSocketStatus;
}


void MQTT_SetTCPConnReinitiationStatus(bool tcpConnectionStatus)
{
	tcpClientSocketStatus = tcpConnectionStatus;
}


mqttCurrentState MQTT_GetHandlerState(void)
{
	return mqttState;
}


void MQTT_ExchangeBufferInit(exchangeBuffer *buffer)
{
	buffer->currentLocation = buffer->start;
	buffer->dataLength = 0;
}


uint16_t MQTT_ExchangeBufferWrite(exchangeBuffer *buffer, uint8_t *data, uint16_t length)
{
	uint8_t *bend = buffer->start + buffer->bufferLength - 1;
	uint8_t *dend = (buffer->currentLocation - buffer->start + buffer->dataLength) % buffer->bufferLength + buffer->start;
    uint16_t i = 0;

	for (i = length; i > 0; i--) 
	{
		if (dend > bend)
		{
			dend = buffer->start;
		}
		if (buffer->dataLength != 0 && dend == buffer->currentLocation)
		{
			break;
		}
		*dend = *data;
		dend++;
		data++;
		buffer->dataLength++;
	}
    
	return length; 
}


uint16_t MQTT_ExchangeBufferPeek(exchangeBuffer *buffer, uint8_t *data, uint16_t length)
{
	uint8_t *ptr = buffer->currentLocation;
	uint8_t *bend = buffer->start + buffer->bufferLength - 1;
	uint16_t i = 0;

	for (i = 0; i < length && i < buffer->dataLength; i++) 
    {
		data[i] = ptr[i];
		if (ptr > bend)
        {
			ptr = buffer->start;
        }
	}

	return i;
}


uint16_t MQTT_ExchangeBufferRead(exchangeBuffer *buffer, uint8_t *data, uint16_t length)
{
	uint8_t *bend = buffer->start + buffer->bufferLength - 1;
	uint16_t i = 0;

	for (i = 0; i < length && buffer->dataLength > 0; i++) 
    {
		data[i] = *buffer->currentLocation;
		buffer->currentLocation++;
		buffer->dataLength--;
		if (buffer->currentLocation > bend)
        {
			buffer->currentLocation = buffer->start;
        }
	}
	return i; 
}


#ifdef USE_NVM_CLIENT_ID
static void  mqttCreateClientID(char *clientID)
{
    const mac48Address_t *mac;
    struct tm *recv_fraction;
    
    time_t theTime = time(NULL);
    recv_fraction = gmtime(&theTime);
    mac = MAC_getAddress();
    sprintf(clientID, "mchp%02x%02x%02x%02x%02x%02x%02x%02x%02x", recv_fraction->tm_hour, recv_fraction->tm_min, recv_fraction->tm_sec, mac->mac_array[0],
                mac->mac_array[1], mac->mac_array[2], mac->mac_array[3], mac->mac_array[4], mac->mac_array[5]);

    nvmem_writeBlock(MQTT_CLIENT_ID_ADDR, clientID, CLIENT_ID_SIZE);
    nvmem_writeByte(MQTT_VALIDITY_CHECK_ADDR, MQTT_CLIENT_ID_CREATED);
}
    

static void mqttGetClientID(char *clientID, uint8_t connectFlags)
{
    if(((connectFlags & CONNECT_CLEAN_SESSION_MASK) == CONNECT_CLEAN_SESSION_MASK) || (nvmem_readByte(MQTT_VALIDITY_CHECK_ADDR) != MQTT_CLIENT_ID_CREATED))
    {
        // Either clean session flag is set to 1 or client ID is being generated 
        // for the first time when cleanSession flag is set to 0. 
        mqttCreateClientID(clientID);
    }
    else
    {
        // Previous session is being continued. Reuse the clientID.
        nvmem_readBlock(MQTT_CLIENT_ID_ADDR, clientID, CLIENT_ID_SIZE);
    }
}
#endif /* USE_NVM_CLIENT_ID */


bool MQTT_CreateConnectPacket(mqttConnectPacket *newConnectPacket)
{
    bool ret;
    uint16_t payloadLength;
    
    payloadLength = 0;
    ret = false;
    
    memset(&txConnectPacket, 0, sizeof(txConnectPacket));
    
    // Fixed header
    txConnectPacket.connectFixedHeaderFlags.controlPacketType = CONNECT;
    txConnectPacket.connectFixedHeaderFlags.duplicate = 0;
    txConnectPacket.connectFixedHeaderFlags.qos = 0;
    txConnectPacket.connectFixedHeaderFlags.retain = 0;
    
    // Variable header    
    txConnectPacket.connectVariableHeader.protocolName[0] = 0x00;
    txConnectPacket.connectVariableHeader.protocolName[1] = 0x04;
    txConnectPacket.connectVariableHeader.protocolName[2] = 'M';
    txConnectPacket.connectVariableHeader.protocolName[3] = 'Q';
    txConnectPacket.connectVariableHeader.protocolName[4] = 'T';
    txConnectPacket.connectVariableHeader.protocolName[5] = 'T';
    txConnectPacket.connectVariableHeader.protocolLevel = 0x04;
	if((newConnectPacket->passwordLength > 0) || (newConnectPacket->usernameLength > 0))
	{
		txConnectPacket.connectVariableHeader.connectFlagsByte.All = 0xC2;
	}
	else
	{
		txConnectPacket.connectVariableHeader.connectFlagsByte.All = 0x02;
	}
	txConnectPacket.connectVariableHeader.keepAliveTimer = htons(newConnectPacket->connectVariableHeader.keepAliveTimer);
	
	// Payload
#ifdef USE_NVM_CLIENT_ID
	mqttGetClientID(txConnectPacket.clientID, txConnectPacket.connectVariableHeader.connectFlagsByte.All);
#else
	txConnectPacket.clientID = newConnectPacket->clientID;
#endif /* USE_NVM_CLIENT_ID */
	txConnectPacket.clientIDLength = strlen(txConnectPacket.clientID);
	if(txConnectPacket.connectVariableHeader.connectFlagsByte.passwordFlag == 1)
	{
		txConnectPacket.password = newConnectPacket->password;
		txConnectPacket.passwordLength = newConnectPacket->passwordLength;
	}
	if(txConnectPacket.connectVariableHeader.connectFlagsByte.usernameFlag == 1)
	{
		txConnectPacket.username = newConnectPacket->username;
		txConnectPacket.usernameLength = newConnectPacket->usernameLength;
	}
	if(txConnectPacket.connectVariableHeader.connectFlagsByte.usernameFlag == 0)
    {
        payloadLength = txConnectPacket.clientIDLength;
    }
    else
    {
        payloadLength = txConnectPacket.clientIDLength + txConnectPacket.passwordLength + txConnectPacket.usernameLength + 4;      
    }
	txConnectPacket.totalLength = sizeof(txConnectPacket.connectVariableHeader) + sizeof(payloadLength) + payloadLength;
    if(txConnectPacket.connectVariableHeader.connectFlagsByte.usernameFlag == 1 || txConnectPacket.connectVariableHeader.connectFlagsByte.passwordFlag == 1)
    {
        txConnectPacket.passwordLength = htons(txConnectPacket.passwordLength);
        txConnectPacket.usernameLength = htons(txConnectPacket.usernameLength);
    }
	txConnectPacket.clientIDLength = htons(txConnectPacket.clientIDLength);
	
	mqttTxFlags.newTxConnectPacket = 1;

	ret = true;
	
	return ret;
}


bool MQTT_CreatePublishPacket(mqttPublishPacket *newPublishPacket)
{
    bool ret;
    
    ret = false;
    
    memset(&txPublishPacket, 0, sizeof(txPublishPacket));
    
    if(mqttState == CONNECTED)
    {
        // Fixed header
        txPublishPacket.publishHeaderFlags.controlPacketType = PUBLISH;
        txPublishPacket.publishHeaderFlags.duplicate = newPublishPacket->publishHeaderFlags.duplicate;
        txPublishPacket.publishHeaderFlags.qos = newPublishPacket->publishHeaderFlags.qos;
        txPublishPacket.publishHeaderFlags.retain = newPublishPacket->publishHeaderFlags.retain;

        // Variable header    
        txPublishPacket.topic = newPublishPacket->topic;
        txPublishPacket.topicLength = strlen(newPublishPacket->topic);

        // Payload
        txPublishPacket.payload = newPublishPacket->payload;
        txPublishPacket.payloadLength = newPublishPacket->payloadLength;
        txPublishPacket.totalLength = sizeof(txPublishPacket.topicLength) + txPublishPacket.topicLength + txPublishPacket.payloadLength;
        txPublishPacket.topicLength = htons(txPublishPacket.topicLength);

        mqttTxFlags.newTxPublishPacket = 1;
        ret = true;
    }
    return ret;
}


bool MQTT_CreateSubscribePacket(mqttSubscribePacket *newSubscribePacket)
{
    bool ret;
    ret = false;

    memset(&txSubscribePacket, 0, sizeof(txSubscribePacket));
    
    // TODO: Check that there is a topic/payload...
    if(mqttState == CONNECTED)
    {
        // Fixed header
		// MQTT-3.8.1-1: Bits 3,2,1,0 of fixed header MUST be set as 0010, else Server MUST treat as malformed
        txSubscribePacket.subscribeHeaderFlags.controlPacketType = SUBSCRIBE;
        txSubscribePacket.subscribeHeaderFlags.duplicate = 0;
        txSubscribePacket.subscribeHeaderFlags.qos = 1;
        txSubscribePacket.subscribeHeaderFlags.retain = 0;
        
        // Variable header    
        txSubscribePacket.packetIdentifierLSB = newSubscribePacket->packetIdentifierLSB;
        txSubscribePacket.packetIdentifierMSB = newSubscribePacket->packetIdentifierMSB;

        // Payload
        for (uint8_t topicCount = 0; topicCount < NUM_TOPICS_SUBSCRIBE; topicCount++)
        {
            txSubscribePacket.subscribePayload[topicCount].topicLength = htons(newSubscribePacket->subscribePayload[topicCount].topicLength);
            txSubscribePacket.subscribePayload[topicCount].topic = newSubscribePacket->subscribePayload[topicCount].topic;
            txSubscribePacket.subscribePayload[topicCount].requestedQoS = newSubscribePacket->subscribePayload[topicCount].requestedQoS;
            txSubscribePacket.totalLength += sizeof(txSubscribePacket.subscribePayload[topicCount].topicLength) + ntohs(txSubscribePacket.subscribePayload[topicCount].topicLength)
                                            + sizeof(txSubscribePacket.subscribePayload[topicCount].requestedQoS);
        }

        // The totalLength field is not essentially a part of the SUBSCRIBE
        // packet. It is used for calculation of the remaining length field.
        txSubscribePacket.totalLength += sizeof(txSubscribePacket.packetIdentifierLSB) + sizeof(txSubscribePacket.packetIdentifierMSB); 
                                       
        mqttTxFlags.newTxSubscribePacket = 1;
        ret = true;
    }
    return ret;
}


static uint8_t mqttEncodeLength(uint16_t length, uint8_t *output)
{
	uint8_t encodedByte;
	uint8_t i = 0;

	do {
		encodedByte = length % 128;
		length /= 128;
        // if there are more data to encode, set the top bit of this byte
		if (length > 0)
        {
			encodedByte |= 0x80;
        }
		output[i] = encodedByte;
		i++;
	} while (length);

	return i; /* Return the amount of bytes used */
}


static bool mqttSendConnect(mqttTxRxInformation *mqttConnectionPtr)
{
	bool ret = false;
    
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff);
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
    
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txConnectPacket.connectFixedHeaderFlags.All, sizeof(txConnectPacket.connectFixedHeaderFlags.All));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txConnectPacket.remainingLength, mqttEncodeLength(txConnectPacket.totalLength, txConnectPacket.remainingLength));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txConnectPacket.connectVariableHeader, sizeof(txConnectPacket.connectVariableHeader));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, (uint8_t *)&txConnectPacket.clientIDLength, sizeof(txConnectPacket.clientIDLength));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txConnectPacket.clientID, strlen(txConnectPacket.clientID));
    
	if((txConnectPacket.passwordLength > 0) || (txConnectPacket.usernameLength > 0))
    {
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, (uint16_t*) &txConnectPacket.usernameLength, sizeof(txConnectPacket.usernameLength));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txConnectPacket.username, ntohs(txConnectPacket.usernameLength));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, (uint16_t*) &txConnectPacket.passwordLength, sizeof(txConnectPacket.passwordLength));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txConnectPacket.password, ntohs(txConnectPacket.passwordLength));
    }
   
    if(mqttTxFlags.newTxConnectPacket == 1)
    {
        ret = MQTT_Send(mqttConnectionPtr);
    }
    if(ret == true)
    {
        mqttTxFlags.newTxConnectPacket = 0;
    } 
    return ret;
}


static bool mqttSendPublish(mqttTxRxInformation *mqttConnectionPtr)
{
    bool ret = false;
    
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff);
    MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
    
    // Copy the txPublishPacket data in TCP Tx buffer
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txPublishPacket.publishHeaderFlags.All, sizeof(txPublishPacket.publishHeaderFlags.All));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txPublishPacket.remainingLength, mqttEncodeLength(txPublishPacket.totalLength, txPublishPacket.remainingLength));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txPublishPacket.topicLength, sizeof(txPublishPacket.topicLength));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txPublishPacket.topic, ntohs(txPublishPacket.topicLength));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txPublishPacket.payload, txPublishPacket.payloadLength);
    
    // Function call to TCP_Send() is abstracted
    if(mqttTxFlags.newTxPublishPacket == 1)
    {
        ret = MQTT_Send(mqttConnectionPtr);
    }
    if(ret == true)
    {
        mqttTxFlags.newTxPublishPacket = 0;
    }
    return ret;
}


static bool mqttSendSubscribe(mqttTxRxInformation *mqttConnectionPtr)
{
	bool ret = false;
    
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff);
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
    
    // Copy the txSubscribePacket data in TCP Tx buffer
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txSubscribePacket.subscribeHeaderFlags.All, sizeof(txSubscribePacket.subscribeHeaderFlags.All));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txSubscribePacket.remainingLength, mqttEncodeLength(txSubscribePacket.totalLength, txSubscribePacket.remainingLength));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txSubscribePacket.packetIdentifierMSB, sizeof(txSubscribePacket.packetIdentifierMSB));
    MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txSubscribePacket.packetIdentifierLSB, sizeof(txSubscribePacket.packetIdentifierLSB));

    for (uint8_t topicCount = 0; topicCount < NUM_TOPICS_SUBSCRIBE; topicCount++)
    {
        MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txSubscribePacket.subscribePayload[topicCount].topicLength, sizeof(txSubscribePacket.subscribePayload[topicCount].topicLength));
        MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, txSubscribePacket.subscribePayload[topicCount].topic, ntohs(txSubscribePacket.subscribePayload[topicCount].topicLength));
        MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txSubscribePacket.subscribePayload[topicCount].requestedQoS, sizeof(txSubscribePacket.subscribePayload[topicCount].requestedQoS));
    }
   
    if(mqttTxFlags.newTxSubscribePacket == 1)
    {
        ret = MQTT_Send(mqttConnectionPtr);
    }
    if(ret == true)
    {
        mqttTxFlags.newTxSubscribePacket = 0;
        mqttRxFlags.newRxSubackPacket = 1;
    } 
    return ret;
   
}


static bool mqttSendPingreq(mqttTxRxInformation *mqttConnectionPtr)
{
    bool ret;
	mqttPingPacket txPingreqPacket;
    
    ret = false;
    memset(&txPingreqPacket,0,sizeof(txPingreqPacket));
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff);
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
	
    // Send a PINGREQ packet here
	txPingreqPacket.pingFixedHeader.controlPacketType = PINGREQ;
	txPingreqPacket.pingFixedHeader.duplicate = 0;
	txPingreqPacket.pingFixedHeader.qos = 0;
	txPingreqPacket.pingFixedHeader.retain = 0;
    txPingreqPacket.remainingLength = 0;
    
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txPingreqPacket.pingFixedHeader.All, sizeof(txPingreqPacket.pingFixedHeader.All));
	MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txPingreqPacket.remainingLength, sizeof(txPingreqPacket.remainingLength));
    
    if(mqttTxFlags.newTxPingreqPacket == 1)
    { 
        ret = MQTT_Send(mqttConnectionPtr);
        if(ret == true)
        {
            mqttTxFlags.newTxPingreqPacket = 0;
            // Expect a PINGRESP packet
            mqttRxFlags.newRxPingrespPacket = 1;
            // The client expects the server to send a PINGRESP within 
            // keepAliveTimer value.
			//The timeout API names are different in MCC foundation
			//services timeout driver and START timeout driver
			timeout_delete(&pingrespTimer);
			timeout_create(&pingrespTimer, (WAITFORPINGRESP_TIMEOUT));
			mqttState = CONNECTED;
        }
    }
    return ret;
}


static bool mqttSendDisconnect(mqttTxRxInformation *mqttConnectionPtr)
{
   bool ret = false;
   mqttDisconnectPacket txDisconnectPacket;
   
   memset(&txDisconnectPacket,0,sizeof(txDisconnectPacket));
   MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff);
   MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
    
   txDisconnectPacket.disconnectFixedHeader.controlPacketType = DISCONNECT;
   txDisconnectPacket.disconnectFixedHeader.retain = 0;
   txDisconnectPacket.disconnectFixedHeader.qos = 0;
   txDisconnectPacket.disconnectFixedHeader.duplicate = 0;  
   
   MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txDisconnectPacket.disconnectFixedHeader.All, sizeof(txDisconnectPacket.disconnectFixedHeader.All));
   MQTT_ExchangeBufferWrite(&mqttConnectionPtr->mqttDataExchangeBuffers.txbuff, &txDisconnectPacket.remainingLength, sizeof(txDisconnectPacket.remainingLength));
    
   ret = MQTT_Send(mqttConnectionPtr);
   
   if(ret == true)
   {
       mqttTxFlags.All = 0;
   }
   
   return ret;
   
}


static mqttCurrentState mqttProcessConnack(mqttTxRxInformation *mqttConnectionPtr)
{	
	mqttConnackPacket_t mqttConnackPacket;	
    
    memset(&mqttConnackPacket, 0, sizeof(mqttConnackPacket));
    
        // Check 1st (4) bytes in Rx MQTT Packet
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &mqttConnackPacket.connackFixedHeader.All, sizeof(mqttConnackPacket.connackFixedHeader.All));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &mqttConnackPacket.remainingLength, sizeof(mqttConnackPacket.remainingLength));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &mqttConnackPacket.connackVariableHeader.connackAcknowledgeFlags.All, sizeof(mqttConnackPacket.connackVariableHeader.connackAcknowledgeFlags.All));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &mqttConnackPacket.connackVariableHeader.connectReturnCode, sizeof(mqttConnackPacket.connackVariableHeader.connectReturnCode));

    if (mqttConnackPacket.connackVariableHeader.connectReturnCode == CONN_ACCEPTED)
    {
        return CONNECTED;
    }
    else
    {	
        return DISCONNECTED;
    }
}


void MQTT_Disconnect()
{    
    if( mqttState == CONNECTED)
    {              
        mqttTxFlags.newTxDisconnectPacket = 1;
    }
}


static void mqttProcessPingresp(mqttTxRxInformation *mqttConnectionPtr)
{	
	mqttPingPacket txPingrespPacket;
    
    memset(&txPingrespPacket, 0, sizeof(txPingrespPacket));
    
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &txPingrespPacket.pingFixedHeader.All, sizeof(txPingrespPacket.pingFixedHeader.All));
    // Reload timeout for keepAliveTimer
    // The timeout should be reloaded only if the keepAliveTimer is set
    // to a non-zero value.
    if(ntohs(txConnectPacket.connectVariableHeader.keepAliveTimer) != 0)
    {
        mqttTxFlags.newTxPingreqPacket = 1;
    }
    // Re-initialise the RX exchange buffer to be able to process the 
    // next incoming MQTT packet
    MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
}


static mqttCurrentState mqttProcessSuback(mqttTxRxInformation *mqttConnectionPtr)
{	
    mqttCurrentState ret;
	mqttSubackPacket rxSubackPacket;

    memset(&rxSubackPacket, 0, sizeof(rxSubackPacket));

    ret = CONNECTED;
    
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxSubackPacket.subscribeAckHeaderFlags.All, sizeof(rxSubackPacket.subscribeAckHeaderFlags.All));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxSubackPacket.remainingLength[0], sizeof(rxSubackPacket.remainingLength[0]));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxSubackPacket.packetIdentifierMSB, sizeof(rxSubackPacket.packetIdentifierMSB)); 
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxSubackPacket.packetIdentifierLSB, sizeof(rxSubackPacket.packetIdentifierLSB));
    // The packetIdentifier of the SUBACK packet must match the
    // packetIdentifier of the SUBSCRIBE packet. Since the library allows
    // the application to create only one SUBSCRIBE packet at a time, 
    // checking this condition becomes simple.
    if((rxSubackPacket.packetIdentifierLSB != txSubscribePacket.packetIdentifierLSB) || (rxSubackPacket.packetIdentifierMSB != txSubscribePacket.packetIdentifierMSB))
    {
        // Change state appropriately
        ret = DISCONNECTED;
    }
    else
    {
        // ToDo remove hardcoding
        MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, rxSubackPacket.returnCode, 1);
        // ToDo This calculation needs to be modified after removing 
        // hardcoding
        uint8_t topicNumbers = (sizeof (rxSubackPacket.returnCode) / sizeof (rxSubackPacket.returnCode[0]));
        for (uint8_t topicCount = 0; topicCount < topicNumbers; topicCount++)
        {
            if(rxSubackPacket.returnCode[topicCount] != txSubscribePacket.subscribePayload[topicCount].requestedQoS)
            {
                // Change state appropriately
                ret = DISCONNECTED;
                break;
            }
        }
    }

    mqttRxFlags.newRxSubackPacket = 0;
    // Re-initialise the RX exchange buffer to be able to process the 
    // next incoming MQTT packet
    MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
    return ret;
}

static mqttCurrentState mqttProcessPublish(mqttTxRxInformation *mqttConnectionPtr)
{
    mqttCurrentState ret;
	mqttPublishPacket rxPublishPacket;

    char mqtt_topic[TOPIC_SIZE];
    char mqtt_payload[PAYLOAD_SIZE];

    memset(&rxPublishPacket, 0, sizeof(rxPublishPacket));
    
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxPublishPacket.publishHeaderFlags.All, sizeof(rxPublishPacket.publishHeaderFlags.All));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxPublishPacket.remainingLength[0], sizeof(rxPublishPacket.remainingLength[0]));
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &rxPublishPacket.topicLength, sizeof(rxPublishPacket.topicLength));
        
    rxPublishPacket.topic = mqtt_topic;
            // ToDo remove hardcoding
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, rxPublishPacket.topic, ntohs(rxPublishPacket.topicLength));
            // ToDo This calculation needs to be modified after removing 
            // hardcoding
    rxPublishPacket.payload = mqtt_payload;
    MQTT_ExchangeBufferRead(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, rxPublishPacket.payload, PAYLOAD_SIZE);
    
        // Re-initialise the RX exchange buffer to be able to process the 
        // next incoming MQTT packet
	MQTT_ExchangeBufferInit(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff);
	ret = CONNECTED;
    return ret;
    
}

uint8_t MQTT_TransmissionHandler(mqttTxRxInformation *mqttConnectionPtr)
{
	bool packetSent;
	uint8_t retMQTTTxHandler, getSetFlag;
	uint16_t keepAliveTimeout;
    
	packetSent = false;
	retMQTTTxHandler = 0;
    getSetFlag = 0;
	keepAliveTimeout = 0;
    
	if(mqttGetTCPConnReinitialisationStatus() == true)
	{
		// At this point TCP connection has been reinitialised.
		bool tcpReinitStatus = false;
		MQTT_SetTCPConnReinitiationStatus(tcpReinitStatus);
		// The MQTT connection needs to be reestablished as well.
		mqttState = DISCONNECTED;
	}

    switch(mqttState)
    {
        case DISCONNECTED:
        if(mqttTxFlags.newTxConnectPacket == 1)
        {
            packetSent = mqttSendConnect(mqttConnectionPtr);
        }
		if(packetSent == true)
        {
            // The timeout API names are different in MCC foundation 
            // services timeout driver and START timeout driver
			timeout_create(&connackTimer, WAITFORCONNACK_TIMEOUT);
            mqttState = WAITFORCONNACK;
        }
            break;
        case CONNECTED:
        // ToDo Find out ways to improve this logic
        if(mqttTxFlags.All > 0)
        {
            while((mqttTxFlags.All & (MQTT_TX_PACKET_DECISION_CONSTANT << getSetFlag)) == 0)
            {   
                getSetFlag++;                
            } 
            mqttConnectTxSubstate = (MQTT_TX_PACKET_DECISION_CONSTANT << getSetFlag) ; 
            switch(mqttConnectTxSubstate)
            {
                case SENDPINGREQ:
					if(pingreqTimeoutOccured == true)
                    {
                        // Change state for the next timeout to occur correctly
						pingreqTimeoutOccured = false;
                        // Periodic sending of PINGREQ packet
                        mqttSendPingreq(mqttConnectionPtr);
                    }
                    break;
                case SENDPUBLISH:
                    timeout_delete(&pingreqTimer);
                    mqttSendPublish(mqttConnectionPtr);
                    keepAliveTimeout = ntohs(txConnectPacket.connectVariableHeader.keepAliveTimer);
                    timeout_create(&pingreqTimer, ((keepAliveTimeout - KEEP_ALIVE_CALCULATION_CONSTANT) * SECONDS));
                    break;
                case SENDSUBSCRIBE:
                    timeout_delete(&pingreqTimer);
                    mqttSendSubscribe(mqttConnectionPtr);
                    keepAliveTimeout = ntohs(txConnectPacket.connectVariableHeader.keepAliveTimer);
                    timeout_create(&pingreqTimer, ((keepAliveTimeout - KEEP_ALIVE_CALCULATION_CONSTANT) * SECONDS));
                    break;
                case SENDDISCONNECT:
                    timeout_delete(&pingreqTimer);
                    packetSent = mqttSendDisconnect(mqttConnectionPtr);
                    if(packetSent == true)
                    {
                      // MQTT_Close(mqttConnectionPtr);
                       mqttState = DISCONNECTED;                                                      
                    }
                    break;
                default:
                    break;
            }
        }
    break;
    default:
		// Go to DISCONNECTED?
        break;
    }
    retMQTTTxHandler = mqttState;
    return retMQTTTxHandler;
}      
    

uint8_t MQTT_ReceptionHandler(mqttTxRxInformation *mqttConnectionPtr)
{
	uint8_t retMQTTRxHandler;
	uint16_t keepAliveTimeout;
	mqttHeaderFlags receivedPacketHeader;
    
	keepAliveTimeout = 0;
	retMQTTRxHandler = 0;
	receivedPacketHeader.All = 0;
    
    if(mqttGetTCPConnReinitialisationStatus() == true)
    {
	    // At this point TCP connection has been reinitialised.
	    bool tcpReinitStatus = false;
	    MQTT_SetTCPConnReinitiationStatus(tcpReinitStatus);
	    // The MQTT connection needs to be reestablished as well.
	    mqttState = DISCONNECTED;
    }

	switch(mqttState)
	{
		case WAITFORCONNACK:
            keepAliveTimeout = ntohs(txConnectPacket.connectVariableHeader.keepAliveTimer);
            if (connackTimeoutOccured == false)
            {
                // The timeout API names are different in MCC foundation 
                // services timeout driver and START timeout driver
                timeout_delete(&connackTimer);
                // Check the type of packet
                MQTT_ExchangeBufferPeek(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &receivedPacketHeader.All, sizeof(receivedPacketHeader.All));
                if(receivedPacketHeader.controlPacketType == CONNACK)
                {
                    mqttState = mqttProcessConnack(mqttConnectionPtr);
                    if((mqttState == CONNECTED) && (keepAliveTimeout != 0))
                    {
                        // Send a PINGREQ packet after (keepAliveTimer - KEEP_ALIVE_CALCULATION_CONSTANT)s
                        // if keepAliveTime is non-zero
                        mqttTxFlags.newTxPingreqPacket = 1;
                        // The timeout API names are different in MCC foundation 
                        // services timeout driver and START timeout driver
                        timeout_create(&pingreqTimer, ((keepAliveTimeout - KEEP_ALIVE_CALCULATION_CONSTANT) * SECONDS));
                    }
                }
                else
                {
                    //If the Client does not receive a CONNACK Packet from the Server within a reasonable amount of time, 
                    //the Client SHOULD close the Network Connection.                    
                    mqttState = DISCONNECTED;
                    MQTT_Close(mqttConnectionPtr);
                }
                
            }
            
            break;
		case CONNECTED:
            // Check the type of packet
            MQTT_ExchangeBufferPeek(&mqttConnectionPtr->mqttDataExchangeBuffers.rxbuff, &receivedPacketHeader.All, sizeof(receivedPacketHeader.All));
            
            switch(receivedPacketHeader.controlPacketType)
            {
                case PINGRESP:
                    // PINGRESP received
    				if((mqttRxFlags.newRxPingrespPacket == 1) && (pingrespTimeoutOccured == false))
                    {
    					timeout_delete(&pingrespTimer);
                        mqttProcessPingresp(mqttConnectionPtr);
                    }
                    else
                    {
                        mqttState = SENDDISCONNECT;
                    }
                    break;
                case SUBACK:
                    // SUBACK received
    				if((mqttRxFlags.newRxSubackPacket == 1))
                    {
                        mqttState = mqttProcessSuback(mqttConnectionPtr);
                    }
                    else
                    {
                        mqttState = SENDDISCONNECT;
                    }
                    break;
                case PUBLISH:
                    // PUBLISH received
                    mqttState = mqttProcessPublish(mqttConnectionPtr);
                    break;                    
                default:
                    break;
            }
            break;
        default:
            break;
    }
	retMQTTRxHandler = mqttState;
	return retMQTTRxHandler;
}

/**********************Function implementations*(END)**************************/
