/*
    \file   mqtt_packetParameters.c

    \brief  MQTT Packet Parameters source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
#include <stdlib.h>
#include <string.h>
#include "../mqtt/mqtt_core/mqtt_client.h"
#include "mqtt_packetPopulate.h"
#include "../core/core.h"
#define MQTT_CID_LENGTH 100
#define MQTT_TOPIC_LENGTH 38

char mqttPassword[456];
char cid[MQTT_CID_LENGTH];
char mqttTopic[MQTT_TOPIC_LENGTH];
//char mqttHostName[] = "a3mnn069kqq6d6-ats.iot.us-west-2.amazonaws.com";
char mqttHostName[] = "a13ulvrmnkhfaj-ats.iot.us-west-2.amazonaws.com";

static bool mqtt_populateConnect(void);
static bool mqtt_populatePublish(uint8_t *publishPayload);

void MQTT_CLIENT_publish(uint8_t *data)
{
    mqttTxRxInformation mqttConnnectionInfo;
    memset(&mqttConnnectionInfo, 0, sizeof(mqttTxRxInformation));
    
    if(mqtt_populatePublish(data) == true)
    {
        MQTT_GetClientConnectionInfo(&mqttConnnectionInfo);
        MQTT_TransmissionHandler(&mqttConnnectionInfo);
    }
}

void MQTT_CLIENT_receive(uint8_t *data, uint8_t len)
{
    MQTT_GetReceivedData(data, len);
	if(MQTT_GetHandlerState() == CONNECTED)
	{
		CORE_receiveEvent(CORE_CONNACK_E);
	}
}

void MQTT_CLIENT_connect(void)
{
    mqttTxRxInformation mqttConnnectionInfo;
    memset(&mqttConnnectionInfo, 0, sizeof(mqttTxRxInformation));

    if(mqtt_populateConnect() == true) // This is always true at this moment of implementation
    {
        MQTT_GetClientConnectionInfo(&mqttConnnectionInfo);
        MQTT_TransmissionHandler(&mqttConnnectionInfo);
    }
}

static bool mqtt_populateConnect(void)
{
    bool ret;
    mqttConnectPacket cloudConnectPacket;

    ret = false;
    memset(&cloudConnectPacket, 0, sizeof(mqttConnectPacket));

    //cloudConnectPacket.connectVariableHeader.connectFlagsByte.All = 0x00;
    cloudConnectPacket.connectVariableHeader.connectFlagsByte.cleanSession = true;
    cloudConnectPacket.connectVariableHeader.connectFlagsByte.usernameFlag = false;
    cloudConnectPacket.connectVariableHeader.connectFlagsByte.passwordFlag = false;
    cloudConnectPacket.connectVariableHeader.keepAliveTimer = 10;
    cloudConnectPacket.clientID = "demo";
    cloudConnectPacket.password = "";
    cloudConnectPacket.passwordLength = 0;
    cloudConnectPacket.username = NULL;
    cloudConnectPacket.usernameLength = 0;

    ret = MQTT_CreateConnectPacket(&cloudConnectPacket);
    return ret;
}


bool mqtt_populatePublish(uint8_t *publishPayload)
{
    bool ret;
    mqttPublishPacket cloudPublishPacket;
    mqttTxRxInformation mqttConnnectionInfo;
    
    ret = false;
    memset(&mqttConnnectionInfo, 0, sizeof(mqttTxRxInformation));
    
    // Fixed header
    cloudPublishPacket.publishHeaderFlags.duplicate = 0;
    cloudPublishPacket.publishHeaderFlags.qos = 0;
    cloudPublishPacket.publishHeaderFlags.retain = 0;
    
    // Variable header
    cloudPublishPacket.topic = (uint8_t*)mqttTopic;
    
    // Payload
    cloudPublishPacket.payload = publishPayload;
    // ToDo Check whether sizeof can be used for integers and strings
    cloudPublishPacket.payloadLength = strlen(cloudPublishPacket.payload);
    
    if(MQTT_CreatePublishPacket(&cloudPublishPacket) == true)
    {
        ret = true;
    }
    
    
    return ret;
}
