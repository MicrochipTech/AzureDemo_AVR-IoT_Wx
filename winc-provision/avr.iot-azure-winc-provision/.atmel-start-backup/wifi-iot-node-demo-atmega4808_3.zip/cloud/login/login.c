/*
    \file   login.c

    \brief  Login source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include "clock_config.h"
#include <util/delay.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include "atmel_start_pins.h"
#include "config/IoT_Sensor_Node_config.h"
#include "login_actions.h"
#include "../mqtt_packetPopulation/mqtt_packetPopulate.h"
#include "../crypto_client/crypto_client.h"
#include "login.h"

typedef loginState_t (*command_t)(loginEvent_t);

static loginState_t ntpReqStatehandler(loginEvent_t e);
static loginState_t bindNtpSockStateHandler(loginEvent_t e);
static void (*notifyObserver)(loginState_t);
static const command_t jwt_state_machine[LOGIN_MAX_STATES] = {
        bindNtpSockStateHandler,
        ntpReqStatehandler,
        NULL,
        NULL,
        NULL,
};
static loginState_t login_current_state;

const char projectId[]     = CFG_PROJECT_ID;
const char projectRegion[] = CFG_PROJECT_REGION;
const char registryId[]    = CFG_REGISTRY_ID;
char deviceId[MAX_PROJECT_METADATA_LENGTH];

static loginState_t bindNtpSockStateHandler(loginEvent_t e)
{
    switch(e)
    {
        case LOGIN_SOCKET_BOUND_E:
            return LOGIN_ACTIONS_ntpReq();
        default:
            return login_current_state;
    }
}

static loginState_t ntpReqStatehandler(loginEvent_t e)
{
    switch(e)
    {
        case LOGIN_NTP_RES_E:
            return LOGIN_ACTIONS_generateJWT();
        case LOGIN_TIMEOUT_E:
            LED_RED_set_level(false);
        default:
            return login_current_state;
    }
}

void LOGIN_createCredentials(void)
{
    char ateccsn[20];
    CRYPTO_CLIENT_printSerialNumber(ateccsn);
    sprintf(deviceId, "d%s", ateccsn);

    sprintf(cid, "projects/%s/locations/%s/registries/%s/devices/%s", projectId, projectRegion, registryId, deviceId);
    sprintf(mqttTopic, "/devices/%s/events", deviceId);
    
	login_current_state = LOGIN_ACTIONS_bindNtpSocket();
}

void LOGIN_receiveEvent(loginEvent_t e)
{
    if(jwt_state_machine[login_current_state] != NULL)
    {
        login_current_state = jwt_state_machine[login_current_state](e);
        if(notifyObserver != NULL)
        {
            notifyObserver(login_current_state);
        }
    }
}

void LOGIN_registerObserver(void *f)
{
    notifyObserver = f;	
}
