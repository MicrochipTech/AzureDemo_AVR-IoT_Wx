/*
    \file   login.h

    \brief  Login header file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/


#ifndef LOGIN_H
#define LOGIN_H

#define MAX_PROJECT_METADATA_LENGTH 30

typedef enum {
    LOGIN_BIND_NTP_SOCK_S,
    LOGIN_NTP_REQ_S,
    LOGIN_GENERATED_S,
    LOGIN_GENERATION_FAILED_S,
    LOGIN_MAX_STATES,
} loginState_t;

typedef enum {
    LOGIN_SOCKET_BOUND_E,
    LOGIN_SOCKET_BIND_FAILED_E,
    LOGIN_NTP_RES_E,
    LOGIN_NTP_REQ_FAILED_E,
    LOGIN_TIMEOUT_E,
    LOGIN_DRIVER_ERROR_E,
    LOGIN_MAX_EVENTS,
} loginEvent_t;

extern const char projectId[MAX_PROJECT_METADATA_LENGTH];
extern const char projectRegion[MAX_PROJECT_METADATA_LENGTH];
extern const char registryId[MAX_PROJECT_METADATA_LENGTH];
extern char deviceId[MAX_PROJECT_METADATA_LENGTH];

void LOGIN_createCredentials(void);
void LOGIN_receiveEvent(loginEvent_t e);
void LOGIN_registerObserver(void *f);

#endif /* LOGIN_H */