/*
    \file   core.c

    \brief  Core source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <stdbool.h>
#include "atmel_start_pins.h"
#include "../core/core_actions.h"
#include "../login/login.h"
#include "core.h"

typedef coreState_t (*command_t)(coreEvent_t);

static coreState_t apProvisionStateHandler(coreEvent_t e);
static coreState_t networkConnectStateHandler(coreEvent_t e);
static coreState_t jwtStateHandler(coreEvent_t e);
static coreState_t dnsReqStateHandler(coreEvent_t e);
static coreState_t transportConnectStateHandler(coreEvent_t e);
static coreState_t applicationConnectStateHandler(coreEvent_t e);
static coreState_t connectedStateHandler(coreEvent_t e);
static bool isProvisionRequested();
static void loginStateTranslator(loginState_t s);

static coreState_t core_current_state;
static const command_t core_state_machine[CORE_MAX_STATES] = {
    apProvisionStateHandler,
    networkConnectStateHandler,
    jwtStateHandler,
    dnsReqStateHandler,
    transportConnectStateHandler,
    applicationConnectStateHandler,
    connectedStateHandler,
    NULL,
    NULL,
};
static uint8_t current_event = CORE_NO_EVENT;

static coreState_t apProvisionStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_RECEIVED_CREDENTIALS_E:
            return CORE_ACTIONS_wifiConnect();
        case CORE_RECEIVED_INVALID_CREDENTIALS_E:
            LED_RED_set_level(false);
            return core_current_state;
        default:
            return core_current_state;
    }
}

static coreState_t networkConnectStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_NETWORK_AVAILABLE_E:
            LED_RED_set_level(true);
            LED_BLUE_set_level(false);
            return CORE_ACTIONS_beginJwtGeneration();
        case CORE_TIMEOUT_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_DRIVER_ERROR_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static coreState_t jwtStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_OK_JWT_E:
            LED_RED_set_level(true);
            return CORE_ACTIONS_dnsReq();
        case CORE_FAILED_JWT_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static coreState_t dnsReqStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_OBTAIN_IP_SUCCESS_E:
             LED_RED_set_level(true);
             return CORE_ACTIONS_tlsConnect();
        case CORE_TIMEOUT_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_dnsReq();
        case CORE_DRIVER_ERROR_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_OBTAIN_IP_FAILED_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_dnsReq();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static coreState_t transportConnectStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_SERVER_ACCEPTED_CONNECTION_E:
            LED_RED_set_level(true);
            return CORE_ACTIONS_mqttConnect();
        case CORE_TIMEOUT_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_tlsConnect();
        case CORE_DRIVER_ERROR_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_SERVER_CLOSED_CONNECTION_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_tlsConnect();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static coreState_t applicationConnectStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_CONNACK_E:
            LED_RED_set_level(true);
            LED_GREEN_set_level(false);
            return CORE_ACTIONS_connected();
        case CORE_TIMEOUT_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_mqttConnect();
        case CORE_DRIVER_ERROR_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_wifiConnect();
        case CORE_SERVER_CLOSED_CONNECTION_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_backOff();
        case CORE_BACKOFF_OK_E:
            return CORE_ACTIONS_tlsConnect();
        case CORE_BACKOFF_FATAL_ERROR_E:
            LED_RED_set_level(false);
            return CORE_ACTIONS_doNothing();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static coreState_t connectedStateHandler(coreEvent_t e)
{
    switch(e)
    {
        case CORE_SERVER_CLOSED_CONNECTION_E:
            LED_GREEN_set_level(true);
            return CORE_ACTIONS_beginJwtGeneration();
        case CORE_LOST_WIFI_E:
            LED_RED_set_level(false);
            LED_GREEN_set_level(true);
            LED_BLUE_set_level(true);
            return CORE_ACTIONS_wifiConnect();
        default:
            return core_current_state;
    }
}

static bool isProvisionRequested()
{
    if (!SW0_get_level())
    {
        return true;
    }
    else
    {
        return false;
    }
}

static void loginStateTranslator(loginState_t s)
{
    switch(s)
    {
        case LOGIN_GENERATED_S:
            CORE_receiveEvent(CORE_OK_JWT_E);
            break;
        case LOGIN_GENERATION_FAILED_S:
            CORE_receiveEvent(CORE_FAILED_JWT_E);
            break;
        default:
            break;
    }
}

coreState_t CORE_firstAction()
{
    if(isProvisionRequested())
    {
        core_current_state = CORE_ACTIONS_enableProvisionAP();
    }
    else
    {
        core_current_state = CORE_ACTIONS_wifiConnect();
    }
    return core_current_state;
}

void CORE_initStateMachine(void)
{
    LOGIN_registerObserver(loginStateTranslator);
}

void CORE_handleEvents(void)
{
    uint8_t e;
    if( current_event != CORE_NO_EVENT)
    {
        if(core_state_machine[core_current_state] != NULL)
        {
            // Calling a state_machine[][] function can produce a CORE_DRIVER_ERROR therefore current_event cannot be changed to NO_EVENT after calling the function because that would loose DRIVER_ERROR event
            e = current_event;
            current_event = CORE_NO_EVENT;
            core_current_state = core_state_machine[core_current_state](e);
        }
    }
}

void CORE_receiveEvent(uint8_t e)
{
    current_event = e;
}

coreState_t CORE_getState(void)
{
    return core_current_state;
}
