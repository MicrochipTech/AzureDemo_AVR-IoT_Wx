/*
    \file   mqtt_comm_layer.h

    \brief  MQTT Client header file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <string.h>
#include "mqtt_comm_layer.h"
#ifdef TCPIP_BSD
#include "cloud/core/core.h"
#include "../mqtt_core/mqtt_client.h"
#elif TCPIP_LITE
#include "mqtt_core/mqtt_client.h"
#endif /* TCPIP_LITE */


#define TX_BUFF_SIZE 400
#define RX_BUFF_SIZE 100
#define USER_LENGTH 0
#define MQTT_KEEP_ALIVE_TIME 120

static mqttTxRxInformation mqttConn;
static uint8_t mqttTxBuff[TX_BUFF_SIZE];
static uint8_t mqttRxBuff[RX_BUFF_SIZE];


void MQTT_ClientInitialise(void)
{
	memset(&mqttConn, 0, sizeof(mqttConn));

	mqttConn.mqttDataExchangeBuffers.txbuff.start = mqttTxBuff;
	mqttConn.mqttDataExchangeBuffers.txbuff.bufferLength = TX_BUFF_SIZE;
	mqttConn.mqttDataExchangeBuffers.rxbuff.start = mqttRxBuff;
	mqttConn.mqttDataExchangeBuffers.rxbuff.bufferLength = RX_BUFF_SIZE;
}

void MQTT_GetClientConnectionInfo(mqttTxRxInformation *mqttConnnectionInfo)
{
	memset(mqttConnnectionInfo, 0, sizeof(mqttTxRxInformation));

	mqttConnnectionInfo->mqttDataExchangeBuffers.txbuff.start = mqttConn.mqttDataExchangeBuffers.txbuff.start;
	mqttConnnectionInfo->mqttDataExchangeBuffers.txbuff.bufferLength = mqttConn.mqttDataExchangeBuffers.txbuff.bufferLength;
	mqttConnnectionInfo->mqttDataExchangeBuffers.txbuff.dataLength = mqttConn.mqttDataExchangeBuffers.txbuff.dataLength;
	mqttConnnectionInfo->mqttDataExchangeBuffers.rxbuff.start = mqttConn.mqttDataExchangeBuffers.rxbuff.start;
	mqttConnnectionInfo->mqttDataExchangeBuffers.rxbuff.bufferLength = mqttConn.mqttDataExchangeBuffers.rxbuff.bufferLength;
	mqttConnnectionInfo->mqttDataExchangeBuffers.rxbuff.dataLength = mqttConn.mqttDataExchangeBuffers.rxbuff.dataLength;
}


bool MQTT_Send(mqttTxRxInformation *connectionPtr)
{
	bool ret = false;
	if(send(tcpClientSocket, connectionPtr->mqttDataExchangeBuffers.txbuff.start, connectionPtr->mqttDataExchangeBuffers.txbuff.dataLength, 0) == SOCK_ERR_NO_ERROR)
	{
		ret = true;
	}
	return ret;
}

bool MQTT_Close(mqttTxRxInformation *connectionPtr)
{
	bool ret = false;
	if(close(tcpClientSocket) == SOCK_ERR_NO_ERROR)
	{
		ret = true;
	}
	return ret;
}


void MQTT_GetReceivedData(uint8_t *pData, uint8_t len)
{
	MQTT_ExchangeBufferInit(&mqttConn.mqttDataExchangeBuffers.rxbuff);
	MQTT_ExchangeBufferWrite(&mqttConn.mqttDataExchangeBuffers.rxbuff, pData, len);
	MQTT_ReceptionHandler(&mqttConn);
}
