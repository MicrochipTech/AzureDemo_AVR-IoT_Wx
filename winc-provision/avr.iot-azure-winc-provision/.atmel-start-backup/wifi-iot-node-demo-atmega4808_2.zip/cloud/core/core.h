/*
    \file   core.h

    \brief  Core header file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/


#ifndef CORE_H
#define CORE_H

#include <stdint.h>
#include "../../winc/socket/include/socket.h"

typedef enum {
    CORE_TIMEOUT_E = 0,
    CORE_RECEIVED_CREDENTIALS_E,
    CORE_RECEIVED_INVALID_CREDENTIALS_E,
    CORE_DRIVER_ERROR_E,
    CORE_OBTAIN_IP_FAILED_E,
    CORE_OBTAIN_IP_SUCCESS_E,
    CORE_OK_JWT_E,
    CORE_FAILED_JWT_E,
    CORE_SERVER_CLOSED_CONNECTION_E,
    CORE_SERVER_ACCEPTED_CONNECTION_E,
    CORE_CONNACK_E,
    CORE_NETWORK_AVAILABLE_E,
    CORE_BACKOFF_FATAL_ERROR_E,
    CORE_BACKOFF_OK_E,
    CORE_LOST_WIFI_E,
    CORE_MAX_EVENTS,
    CORE_NO_EVENT,
} coreEvent_t;

typedef enum {
    CORE_AP_PROVISION_S = 0,
    CORE_NETWORK_CONNECT_S,
    CORE_JWT_S,
    CORE_DNS_REQ_S,
    CORE_TRANSPORT_CONNECT_S,
    CORE_APPLICATION_CONNECT_S,
    CORE_CONNECTED_S,
    CORE_STOP_S,
    CORE_MAX_STATES,
} coreState_t;

void CORE_initStateMachine(void);
coreState_t CORE_firstAction();
void CORE_handleEvents(void);
void CORE_receiveEvent(uint8_t e);
coreState_t CORE_getState(void);

extern uint32 mqttGoogleApisComIP;
extern SOCKET tcpClientSocket;

#endif /* CORE_H */