/*
    \file   actions.c

    \brief  Application Core source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
#define F_CPU 10000000UL
#define DEFAULT_WAIT_TIME 5000
#include <util/delay.h>

#include <string.h>
#include <stdio.h>
#include "winc/driver/include/m2m_wifi.h"
#include "timeout.h"
#include "Config/IoT_Sensor_Node_config.h"
#include "../network_control/network_control.h"
#include "../mqtt_packetPopulation/mqtt_packetPopulate.h"
#include "../../mqtt/mqtt_core/mqtt_client.h"
#include "../credentials_storage/credentials_storage.h"
#include "../login/login.h"
#include "core_actions.h"

#define MAX_BACK_OFF_RETRIES 8

#define MAIN_WLAN_SSID				CFG_MAIN_WLAN_SSID
#define MAIN_WLAN_AUTH				CFG_MAIN_WLAN_AUTH
#define MAIN_WLAN_PSK				CFG_MAIN_WLAN_PSK 
#define WLAN_AP_NAME				CFG_WLAN_AP_NAME
#define WLAN_AP_CHANNEL				1
#define WLAN_AP_WEP_INDEX			0
#define WLAN_AP_WEP_SIZE			WEP_40_KEY_STRING_SIZE
#define WLAN_AP_WEP_KEY				"1234567890"
#define WLAN_AP_SECURITY			M2M_WIFI_SEC_OPEN
#define WLAN_AP_MODE				SSID_MODE_VISIBLE
#define WLAN_AP_DOMAIN_NAME			CFG_WLAN_AP_NAME
#define WLAN_AP_IP_ADDRESS			CFG_WLAN_AP_IP_ADDRESS

SOCKET tcpClientSocket = -1;

uint32 mqttGoogleApisComIP;

static timer_struct_t wait_timer;
static absolutetime_t wait_timer_cb(void *payload);

static uint8_t backOffIntervals[MAX_BACK_OFF_RETRIES] = {1, 2, 4, 8, 16, 32, 32, 32};
static timer_struct_t wait_timer, back_off_timer;
static uint16_t back_off_time;

static absolutetime_t back_off_timer_cb(void *payload);
static uint8_t connectAttemptCnt;

static void startWaiting();

coreState_t CORE_ACTIONS_enableProvisionAP(void)
{
    tstrM2MAPConfig apConfig = {
        WLAN_AP_NAME, // Access Point Name.
        WLAN_AP_CHANNEL, // Channel to use.
        WLAN_AP_WEP_INDEX, // Wep key index.
        WLAN_AP_WEP_SIZE, // Wep key size.
        WLAN_AP_WEP_KEY, // Wep key.
        WLAN_AP_SECURITY, // Security mode.
        WLAN_AP_MODE, // SSID visible.
        WLAN_AP_IP_ADDRESS // DHCP server IP
    };
    static CONST char gacHttpProvDomainName[] = WLAN_AP_DOMAIN_NAME;
    m2m_wifi_start_provision_mode((tstrM2MAPConfig *)&apConfig, (char*)gacHttpProvDomainName, 1);

    return CORE_AP_PROVISION_S;
}

coreState_t CORE_ACTIONS_wifiConnect(void)
{
    CREDENTIALS_STORAGE_read(ssid, pass, authType);

    if (ssid[0] ==  0xFF)
    {

        for (uint8_t j = 0; j < MAX_WIFI_CREDENTIALS_LENGTH; j++)
        {
            ssid[j] = 0;
            pass[j] = 0;
        }
        strcpy(ssid, MAIN_WLAN_SSID);
        strcpy(pass, MAIN_WLAN_PSK);
        itoa(MAIN_WLAN_AUTH, (char*)authType, 10);
    }
	
    if(M2M_SUCCESS != m2m_wifi_connect((char *)ssid, sizeof(ssid), atoi((char*)authType), (char *)pass, M2M_WIFI_CH_ALL))
    {
        CORE_receiveEvent(CORE_DRIVER_ERROR_E);
    } 
    else 
    {
        socketInit();
        registerSocketCallback(NETWORK_CONTROL_socketHandler, NETWORK_CONTROL_dnsHandler);
        startWaiting();
    }
	
    return CORE_NETWORK_CONNECT_S;
}

coreState_t CORE_ACTIONS_beginJwtGeneration(void)
{
    LOGIN_createCredentials();
    return CORE_JWT_S;
}

coreState_t CORE_ACTIONS_dnsReq(void)
{
    int8_t retVal = gethostbyname((uint8_t*)mqttHostName);	
    if (retVal != SOCK_ERR_NO_ERROR) 
    {
        CORE_receiveEvent(CORE_DRIVER_ERROR_E);
    }
    else 
    {
        connectAttemptCnt = 0;
        startWaiting();
    }
    return CORE_DNS_REQ_S;
}

coreState_t CORE_ACTIONS_tlsConnect(void)
{
    struct sockaddr_in addr;
    bool tcpReinitiationStatus;

    close(tcpClientSocket);
    tcpClientSocket = -1;
    tcpReinitiationStatus = true;

    MQTT_SetTCPConnReinitiationStatus(tcpReinitiationStatus);

    if ((tcpClientSocket = socket(AF_INET, SOCK_STREAM, 1)) < 0)
    {
        CORE_receiveEvent(CORE_DRIVER_ERROR_E);
    }
    else
    {
        addr.sin_family = AF_INET;
        addr.sin_port = _htons(8883);
        addr.sin_addr.s_addr = mqttGoogleApisComIP;

        sint8 ret = connect(tcpClientSocket, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

        _delay_ms(500);

        if (ret < 0)
        {
            close(tcpClientSocket);
            tcpClientSocket = -1;
            CORE_receiveEvent(CORE_DRIVER_ERROR_E);
        }	
        else
        {
            startWaiting();
        }
    }

    return CORE_TRANSPORT_CONNECT_S;
}

coreState_t CORE_ACTIONS_mqttConnect(void)
{
    MQTT_CLIENT_connect();
    startWaiting();

    return CORE_APPLICATION_CONNECT_S;
}

coreState_t CORE_ACTIONS_connected(void)
{
    return CORE_CONNECTED_S;
}

coreState_t CORE_ACTIONS_doNothing(void) 
{
    return CORE_STOP_S;
}

coreState_t CORE_ACTIONS_backOff(void)
{
    if(connectAttemptCnt < MAX_BACK_OFF_RETRIES)
    {
        back_off_time = backOffIntervals[connectAttemptCnt++] * 1000 + rand() % 1000;
        back_off_timer.callback_ptr = back_off_timer_cb;
        scheduler_timeout_delete(&back_off_timer);
        scheduler_timeout_create(&back_off_timer, back_off_time);
    }
    else
    {
    CORE_receiveEvent(CORE_BACKOFF_FATAL_ERROR_E);
    }

    return CORE_getState();
}


static absolutetime_t wait_timer_cb(void *payload)
{
    CORE_receiveEvent(CORE_TIMEOUT_E);
    return 0;
}

static void startWaiting()
{
    scheduler_timeout_delete(&wait_timer);
    wait_timer.callback_ptr = wait_timer_cb;
    scheduler_timeout_create(&wait_timer, DEFAULT_WAIT_TIME);
}

static absolutetime_t back_off_timer_cb(void *payload)
{
    CORE_receiveEvent(CORE_BACKOFF_OK_E);
    return 0;
}
