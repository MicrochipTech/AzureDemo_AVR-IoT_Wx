/*
    \file   login_networking.c

    \brief  Login networking source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/  

#include <stdint.h>
#include <string.h>
#include "../login/login.h"
#include "../ntp/ntp.h"
#include "login_networking.h"

#define MAIN_WIFI_M2M_BUFFER_SIZE		48
uint8_t socketBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];

void LOGIN_NETWORKING_wifiHandler(uint8_t msgType, void *pMsg)
{
    // This module does not use WiFi events
}

void LOGIN_NETWORKING_socketHandler(SOCKET sock, uint8_t msgType, void *pMsg)
{
    int16_t ret;
    uint8_t packetBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];
    tstrSocketBindMsg *pstrBind;
    tstrSocketRecvMsg *pstrRx;
    
    switch (msgType) {
        case SOCKET_MSG_BIND:
            pstrBind = (tstrSocketBindMsg *)pMsg;
            if (pstrBind && pstrBind->status == 0) {
                ret = recvfrom(sock, socketBuffer, MAIN_WIFI_M2M_BUFFER_SIZE, 0);
                if (ret != SOCK_ERR_NO_ERROR) 
                {
                    LOGIN_receiveEvent(LOGIN_SOCKET_BIND_FAILED_E);
                } 
                else 
                {
                    LOGIN_receiveEvent(LOGIN_SOCKET_BOUND_E);
                }
            } 
            else 
            {
                LOGIN_receiveEvent(LOGIN_SOCKET_BIND_FAILED_E);
            }
            break;
        
        case SOCKET_MSG_RECVFROM:
            pstrRx = (tstrSocketRecvMsg *)pMsg;
            if (pstrRx->pu8Buffer && pstrRx->s16BufferSize) 
            {
                memcpy(packetBuffer, pstrRx->pu8Buffer, sizeof(packetBuffer));

                if ((packetBuffer[0] & 0x7) != 4) 
                {
                    LOGIN_receiveEvent(LOGIN_NTP_REQ_FAILED_E);
                } 
                else 
                {
                    NTP_receiveData(packetBuffer);
                    ret = close(sock);
                    if (ret == SOCK_ERR_NO_ERROR) 
                    {
                        sock = -1;
                    }
                }
            }
            break;
             
        default:
            break;
    }
}

void LOGIN_NETWORKING_dnsHandler(uint8* domainName, uint32 serverIP)
{
    // This module does not use use DNS
}
