/*
 * kit_process.h
 *
 * Created: 11/14/2018 4:18:52 PM
 *  Author: M17336
 */ 


#ifndef KIT_PROCESS_H_
#define KIT_PROCESS_H_

#include "kit_protocol/kit_protocol_interpreter.h"
#include "kit_protocol/kit_protocol_utilities.h"
#include "parson_json/parson.h"

enum kit_protocol_status process_board_application_init(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_set_wifi(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_get_status(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_gen_key(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_gen_csr(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_save_credentials(JSON_Object *params_object, JSON_Object *result_object);
enum kit_protocol_status process_board_application_reset_kit(JSON_Object *params_object, JSON_Object *result_object);

ATCA_STATUS kit_protocol_write_device_cert(char *certificate);
ATCA_STATUS kit_protocol_write_signer_cert(char *certificate);

#endif /* KIT_PROCESS_H_ */